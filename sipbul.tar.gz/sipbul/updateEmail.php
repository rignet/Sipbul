<html>

<link rel="STYLESHEET" type="text/css" href="styles.css">
<link rel="STYLESHEET" type="text/css" href="tree.css">

<head>

<script language="Javascript">
<!--
if (document.images) {
//on buttons
	imgBoldon = new Image();
	imgBoldon.src = "images/bold_on.gif";
	imgItalicon = new Image();
	imgItalicon.src = "images/italic_on.gif";
	imgUnderlineon = new Image();
	imgUnderlineon.src = "images/underline_on.gif";
	imgOrderedListon = new Image();
	imgOrderedListon.src = "images/orderedlist_on.gif";
	imgUnorderedListon = new Image();
	imgUnorderedListon.src = "images/unorderedlist_on.gif";
	imgAlignLefton = new Image();
	imgAlignLefton.src = "images/alignleft_on.gif";
	imgAlignCenteron = new Image();
	imgAlignCenteron.src = "images/aligncenter_on.gif";
	imgAlignRighton = new Image();
	imgAlignRighton.src = "images/alignright_on.gif";
	imgInsertLinkon = new Image();
	imgInsertLinkon.src = "images/insertlink_on.gif";
	imgClearHtmlon = new Image();
	imgClearHtmlon.src = "images/clearhtml_on.gif";

//off buttons
	imgBoldoff = new Image();
	imgBoldoff.src = "images/bold_off.gif";
	imgItalicoff = new Image();
	imgItalicoff.src = "images/italic_off.gif";
	imgUnderlineoff = new Image();
	imgUnderlineoff.src = "images/underline_off.gif";
	imgOrderedListoff = new Image();
	imgOrderedListoff.src = "images/orderedlist_off.gif";
	imgUnorderedListoff = new Image();
	imgUnorderedListoff.src = "images/unorderedlist_off.gif";
	imgAlignLeftoff = new Image();
	imgAlignLeftoff.src = "images/alignleft_off.gif";
	imgAlignCenteroff = new Image();
	imgAlignCenteroff.src = "images/aligncenter_off.gif";
	imgAlignRightoff = new Image();
	imgAlignRightoff.src = "images/alignright_off.gif";
	imgInsertLinkoff = new Image();
	imgInsertLinkoff.src = "images/insertlink_off.gif";
	imgClearHtmloff = new Image();
	imgClearHtmloff.src = "images/clearhtml_off.gif";
}

function changeImages() {
	if (document.images) {
		for (var i=0; i<changeImages.arguments.length; i+=2) {
			document[changeImages.arguments[i]].src = eval(changeImages.arguments[i+1] + ".src");
		}
	}
}

function StoreCaret (textEl) {
	var optionObject;
	optionObject = eval(textEl);

	if (optionObject.createTextRange) {
		optionObject.caretPos = document.selection.createRange().duplicate();
	}
}

function InsertAddLink (textEl,strType) {
	var url = prompt('Enter the URL location :','http:\/\/')
	var optionObject;
	optionObject = eval(textEl);
	if (url != null) {
		var strResultText = "";
		strResultText = (document.all) ? document.selection.createRange().text :
		document.frmContentTemplateStoryEditor.text.value = strResultText ;
		document.selection.createRange().text = "";
		var caretPos = optionObject.caretPos;
		caretPos.text = caretPos.text.charAt(caretPos.text.length) == ' ' ? strOpen + ' ':
		'<a href=\"' + url + '\">' + strResultText + '</a>';
	}
	window.status=strType;
}

function InsertAtCursor (textEl,strOpen,strClose,strType) {
	var strResultText = "";
	var optionObject;
	optionObject = eval(textEl);
	strResultText = (document.all) ? document.selection.createRange().text :
	document.frmContentTemplateStoryEditor.text.value = strResultText ;
	document.selection.createRange().text = "";
	if (optionObject.createTextRange && optionObject.caretPos) {
		var caretPos = optionObject.caretPos;
		caretPos.text = caretPos.text.charAt(caretPos.text.length) == ' ' ? strOpen + ' ':
		strOpen + strResultText + strClose;
	}
	window.status=strType;
}

function InsertLists(textEl,strOpen,strClose,strDivider,strType) {
	var strResultText = "";
	var optionObject;
	optionObject = eval(textEl);
	strResultText = (document.all) ? document.selection.createRange().text :
	document.frmContentTemplateStoryEditor.text.value = strResultText ;
	var strOutPut = "";
	document.selection.createRange().text = "";
	if (optionObject.createTextRange && optionObject.caretPos) {
		for (var i = 0; i < strResultText.length; i++) {
			if ((strResultText.charCodeAt(i) == 13) && (strResultText.charCodeAt(i + 1) == 10)) {
				i++;
				strOutPut += "\r\n" + strDivider;
			}
			else {
				strOutPut += strResultText.charAt(i);
			}
		}
		var caretPos = optionObject.caretPos;
		caretPos.text = caretPos.text.charAt(caretPos.text.length) == ' ' ? strOpen + ' ':
		strOpen + strDivider + strOutPut + strClose + "\r\n";
	}
	window.status=strType;
}

function ClearTags(textEl,strType) {
	var optionObject;
	optionObject = eval(textEl);
	if (!confirm("Are you sure you want to delete the HTML in the " + strType + "?")) {
		optionObject = optionObject.value.replace(/<[^>]*>/g,'');
	//	document.frmContentTemplateStoryEditor.strContentTemplateHeader.value = textEl.replace(/<[^>]*>/g,'');
	}
}

function ConvertBR(input) {
// Converts carriage returns
// to <BR> for display in HTML
	var output = "";
	for (var i = 0; i < input.length; i++) {
		if ((input.charCodeAt(i) == 13) && (input.charCodeAt(i + 1) == 10)) {
			i++;
			output += "<BR>";
		}
		else {
			output += input.charAt(i);
		}
	}
	return output;
}

function replaceChars(strFind,strReplace,strHTML) {
	temp = '' + strHTML; // temporary holder

	while (temp.indexOf(strFind)>-1) {
		pos= temp.indexOf(strFind);
		temp = '' + (temp.substring(0, pos) + strReplace + temp.substring((pos + strFind.length), temp.length));
	}
	return temp;
}


function AddUser()
	{
	//var from = document.frmMail.from.value
	//var to = document.frmMail.to.value
	//var mailtext = document.frmMail.mailtext.value
	setup2 = 'toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=no,copyhistory=no,width=670,height=550';
	pop = window.open ("addUser.php","pop",setup2);

}

function StartTZChanged()
{
	document.frmMail.endtimezone.value= document.frmMail.starttimezone.value;
}

function EndTZChanged()
{
	document.frmMail.starttimezone.value= document.frmMail.endtimezone.value;
}

function FixTimeZones(strZone, strSeverity)
{
	document.frmMail.starttimezone.value= strZone;
	document.frmMail.endtimezone.value= strZone;

	for (var i=0;i<document.frmMail.icontype.length;i++) {
//alert( "[" + strSeverity + "]:[" + document.frmMail.icontype[i].value + "]" );
		if (document.frmMail.icontype[i].value == strSeverity) {
			document.frmMail.icontype[i].checked = true;
		}
	}
}



function Preview(form)
	{


	// Initialize to empty string jpr 5-6-06
	document.frmMail.service.value= '';
	document.frmMail.region.value= '';

	for (var i=0;i<document.frmMail.icontype.length;i++) {
		if (document.frmMail.icontype[i].checked) {
			document.frmMail.emailIcon.value = document.frmMail.icontype[i].value
		}
	}


	for (var i=0;i<document.frmMail.services.length;i++) {
		if (document.frmMail.services[i].checked) {
			if (i == 0) {
				document.frmMail.service.value = document.frmMail.services[i].value;
			}
			else {
				document.frmMail.service.value = document.frmMail.service.value + ', ' + document.frmMail.services[i].value;
			}
		}

	}

	for (var i=0;i<document.frmMail.regions.length;i++) {
		if (document.frmMail.regions[i].checked) {
			if (i == 0) {
				document.frmMail.region.value = document.frmMail.regions[i].value;
			}
			else {
				document.frmMail.region.value = document.frmMail.region.value + ', ' + document.frmMail.regions[i].value;
			}
		}

	}
	var from = 'Stratos Admin < operations@stratosglobal.com >';
	//var to = form.to.value;
	//var bcc = form.bcc.value;


	var subject = form.subject.value;
	var service = '<b>Please be advised of an interruption to the following Stratos service(s):</b>' + form.service.value;
	var severity = '<br><br><b>Severity: </b>'+ document.frmMail.emailIcon.value;
	var regions = '<br><br><b>Region(s) Affected:</b>' + form.region.value;
	//var type = '<br><br><b>Email Type:</b> <img src=\"images/icon_' + form.emailIcon.value + '.gif\" width=\"16\" height=\"16\" border=\"0\" alt=\"' + form.emailIcon.value + '\">';
	var startdate = '<br><b><br>Interruption Window Start Date and Time:</b> ' + form.startdate.value  + ' ' + form.starttimezone.value;
	//var starttime = '<br><br><b>Interruption Window Start Time:</b> ' + form.starttime.value;

	if (form.unknownend.checked == false) {

		var endtime = '<br><br><b>Interruption Window End Date and Time:</b> ' + form.endtime.value  + ' ' + form.endtimezone.value;


		var startSplit= form.startdate.value.split(" ");
		startSplit[1] += ":00";

		var startDateSecondSplit= startSplit[0].split("-");
		var startTimeSecondSplit= startSplit[1].split(":");

		var startDateObj= new Date;
		startDateObj.setHours(startTimeSecondSplit[0]);
		startDateObj.setMinutes(startTimeSecondSplit[1]);
		startDateObj.setSeconds(startTimeSecondSplit[2]);
		startDateObj.setMonth(startDateSecondSplit[1]-1);
		startDateObj.setDate(startDateSecondSplit[2]);
		startDateObj.setYear(startDateSecondSplit[0]);
	
		var endSplit= form.endtime.value.split(" ");
		endSplit[1] += ":00";
		var endDateSecondSplit= endSplit[0].split("-");

		var endTimeSecondSplit= endSplit[1].split(":");
	
		var endDateObj= new Date;
		endDateObj.setHours(endTimeSecondSplit[0]);
		endDateObj.setMinutes(endTimeSecondSplit[1]);
		endDateObj.setSeconds(endTimeSecondSplit[2]);
		endDateObj.setMonth(endDateSecondSplit[1]-1);
		endDateObj.setDate(endDateSecondSplit[2]);
		endDateObj.setYear(endDateSecondSplit[0]);

		var durationMinutes= (endDateObj.getTime() - startDateObj.getTime()) / (1000*60);
		var durationText=" ";

		if (durationMinutes <= 0) {
			alert( 'Please Make the End Date/Time later than the Start Date/Time')
			return(null);
		}

		if ( durationMinutes < 60 ) {
			durationText= Math.floor(durationMinutes) + " Minute";
			if (Math.floor(durationMinutes) != 1)
				durationText+= 's';
		}
		else if ( durationMinutes < ( 24*60) ) {
			durationText= Math.floor(durationMinutes/60) + " Hour";
			if (Math.floor(durationMinutes/60) != 1)
				durationText+= 's';
		}
		else if ( durationMinutes < ( 2*7*24*60) ) {
			durationText= Math.floor(durationMinutes/(24*60)) + " Day";
			if (Math.floor(durationMinutes/(24*60)) != 1)
				durationText+= 's';
		}
		else if ( durationMinutes < ( 2*30*24*60) ) {
			durationText= Math.floor(durationMinutes/(7*24*60)) + " Week";
			if (Math.floor(durationMinutes/(7*24*60)) != 1)
				durationText+= 's';
		}
		else	{
			durationText= Math.floor(durationMinutes/(30*24*60)) + " Month";
			if (Math.floor(durationMinutes/30*24*60) != 1)
				durationText+= 's';
		}

		var appduration = '<br><br><b>Approximate Duration:</b> ' + durationText;

	}
	else {
		var endtime = '<br><br><b>Interruption Window End Date and Time:</b> Unknown';
		var appduration = '<br><br><b>Approximate Duration:</b> Unknown'; 
	}




//	var endtime = '<br><br><b>Interruption Window End Date and Time:</b> ' + form.endtime.value  + ' ' + form.endtimezone.value;
//	var appduration = '<br><br><b>Approximate Duration:</b> ' + form.appduration.value;


	var mailtext1 = '<br><br><b>Reason:</b> ' + form.mailtext1.value;
	var mailtext2 = '<br><b>Update:</b> ' + form.mailtext2.value;
	
	if (document.frmMail.emailIcon.value == '') {
		alert( 'Please Select a Severity')
		return(null);
	}

	//var mailtext2 = form.mailtext2.value;
	//pop = window.open('','popup', 'scrollbars = yes, toolbar = no, status = no');
	setup1 = 'toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=no,copyhistory=no,width=670,height=550';
	var pop = window.open ('','Preview',setup1);
	pop.document.open();
	pop.document.writeln('<head>');
	pop.document.writeln('<Title>');
	pop.document.writeln('Preview');
	pop.document.writeln('</Title>');
	pop.document.writeln('<link rel=\"STYLESHEET\" type=\"text/css\" href=\"styles.css\">');
	pop.document.writeln('<link rel=\"STYLESHEET\" type=\"text/css\" href=\"tree.css\">');
	pop.document.writeln('</head>');
	pop.document.writeln('<body>');
	pop.document.writeln('<div id=\"p7swapmenu\">');
	pop.document.writeln('<center>');
	pop.document.writeln('<h2>Preview</h2><br>');
	pop.document.writeln('</center>');
	pop.document.writeln('<form method=post action=\"\" name=\"frmMail\" id=\"frmMail\">');
	pop.document.writeln('<table>');
	pop.document.writeln('<tr>');
	pop.document.writeln('<td colspan=\"2\"><b>From:&nbsp;&nbsp;</b></td> <td colspan=\"2\">' + from + '</td>');
	//pop.document.writeln('<br>');
	pop.document.writeln('</tr>');
	pop.document.writeln('<tr>');
	pop.document.writeln('<td colspan=\"2\"><b>Subject:&nbsp;&nbsp;</b></td> <td colspan=\"2\"> ' + subject + '</td>');
	//pop.document.writeln('<br>');
	pop.document.writeln('</tr>');
	pop.document.writeln('<tr>');
//	pop.document.writeln('<td colspan=\"2\"><b>Message:&nbsp;&nbsp;</b></td> <td colspan=\"2\"> ' + service + severity + regions + startdate + endtime + appduration + '<br>' + mailtext1 + '<br>' + mailtext2 + '<br><br>' + '</td>');
pop.document.writeln('<td colspan=\"2\"><b>Message:&nbsp;&nbsp;</b></td> <td colspan=\"2\"> ' + service + severity + regions + startdate + endtime + appduration + '<br>' + mailtext2 + '<br>' + mailtext1 + '<br><br>' + '</td>');
	//pop.document.writeln('<br>');
	pop.document.writeln('</tr>');
	pop.document.writeln('</table>');
	pop.document.writeln('</form>');
	pop.document.writeln('<br><p><center><a href="javascript:window.close();">Close Window</a></p>');
	pop.document.writeln('</div>');
	pop.document.writeln('</body>');
	pop.document.close();
}






function ProcessForm(){
			var testresults;
			var strSubmitMessage = '';
			var blnStopSubmission = false;

			// Initialize to empty string jpr 5-9-06
			document.frmMail.service.value= '';
			document.frmMail.region.value= '';

			//Validate Launch Date
			if (isEmpty(document.frmMail.fromemail.value)) {
				blnStopSubmission = true;
				strSubmitMessage = strSubmitMessage + '\      Please Enter From Email\n';
			}


			//Validate Subject
			//alert(document.frmMail.subject.value);
			if (isEmpty(document.frmMail.subject.value)) {
				blnStopSubmission = true;
				strSubmitMessage = strSubmitMessage + '\      Please Select a Subject\n';
			}


			for (var i=0;i<document.frmMail.icontype.length;i++) {
				if (document.frmMail.icontype[i].checked) {
					document.frmMail.emailIcon.value = document.frmMail.icontype[i].value
				}
	
			}

			if (isEmpty(document.frmMail.emailIcon.value)) {
				blnStopSubmission = true;
				strSubmitMessage = strSubmitMessage + '\      Please Select a Severity\n';
			}
			// jpr 5-9-05 alert(document.frmMail.emailIcon.value);



			for (var i=0;i<document.frmMail.services.length;i++) {
				if (document.frmMail.services[i].checked) {
					if ((i == 0) || (isEmpty(document.frmMail.service.value))) {
						document.frmMail.service.value = document.frmMail.services[i].value;
					}
					else {
						document.frmMail.service.value = document.frmMail.service.value + ', ' + document.frmMail.services[i].value;
					}
				}

			}

			if (isEmpty(document.frmMail.service.value)) {
				blnStopSubmission = true;
				strSubmitMessage = strSubmitMessage + '\      Please Select a Service\n';
			}
			//alert(document.frmMail.service.value);


			for (var i=0;i<document.frmMail.regions.length;i++) {
				if (document.frmMail.regions[i].checked) {
					if ((i == 0) || (isEmpty(document.frmMail.region.value))) {
						document.frmMail.region.value = document.frmMail.regions[i].value;
					}
					else {
						document.frmMail.region.value = document.frmMail.region.value + ', ' + document.frmMail.regions[i].value;
					}
				}

			}

			if (isEmpty(document.frmMail.region.value)) {
				blnStopSubmission = true;
				strSubmitMessage = strSubmitMessage + '\      Please Select a Region\n';
			}
			//alert(document.frmMail.icontype.value);

	if (document.frmMail.unknownend.checked == false) {

		// Calculate the outage duration
		var startSplit= document.frmMail.startdate.value.split(" ");
		startSplit[1] += ":00";

		var startDateSecondSplit= startSplit[0].split("-");
		var startTimeSecondSplit= startSplit[1].split(":");

		var startDateObj= new Date;
		startDateObj.setHours(startTimeSecondSplit[0]);
		startDateObj.setMinutes(startTimeSecondSplit[1]);
		startDateObj.setSeconds(startTimeSecondSplit[2]);
		startDateObj.setMonth(startDateSecondSplit[1]-1);
		startDateObj.setDate(startDateSecondSplit[2]);
		startDateObj.setYear(startDateSecondSplit[0]);
	
		var endSplit= document.frmMail.endtime.value.split(" ");
		endSplit[1] += ":00";
		var endDateSecondSplit= endSplit[0].split("-");

		var endTimeSecondSplit= endSplit[1].split(":");
	
		var endDateObj= new Date;
		endDateObj.setHours(endTimeSecondSplit[0]);
		endDateObj.setMinutes(endTimeSecondSplit[1]);
		endDateObj.setSeconds(endTimeSecondSplit[2]);
		endDateObj.setMonth(endDateSecondSplit[1]-1);
		endDateObj.setDate(endDateSecondSplit[2]);
		endDateObj.setYear(endDateSecondSplit[0]);

		var durationMinutes= (endDateObj.getTime() - startDateObj.getTime()) / (1000*60);
		var durationText=" ";

		if (durationMinutes <= 0) {
			alert( 'Please Make the End Date/Time later than the Start Date/Time')
			return(null);
		}

		if ( durationMinutes < 60 ) {
			durationText= Math.floor(durationMinutes) + " Minute";
			if (Math.floor(durationMinutes) != 1)
				durationText+= 's';
		}
		else if ( durationMinutes < ( 24*60) ) {
			durationText= Math.floor(durationMinutes/60) + " Hour";
			if (Math.floor(durationMinutes/60) != 1)
				durationText+= 's';
		}
		else if ( durationMinutes < ( 2*7*24*60) ) {
			durationText= Math.floor(durationMinutes/(24*60)) + " Day";
			if (Math.floor(durationMinutes/(24*60)) != 1)
				durationText+= 's';
		}
		else if ( durationMinutes < ( 2*30*24*60) ) {
			durationText= Math.floor(durationMinutes/(7*24*60)) + " Week";
			if (Math.floor(durationMinutes/(7*24*60)) != 1)
				durationText+= 's';
		}
		else	{
			durationText= Math.floor(durationMinutes/(30*24*60)) + " Month";
			if (Math.floor(durationMinutes/30*24*60) != 1)
				durationText+= 's';
		}

		var appduration = durationText;

	}
	else {
		var endtime = 'Unknown';
		var appduration = 'Unknown'; 
	}

		document.frmMail.appduration.value= appduration;

			//Submit the form
			if(!blnStopSubmission) {
				document.frmMail.submit();
			}
			else {
				alert(strSubmitMessage);
			}
	}

	//Check whether string s is empty.
	function isEmpty(s) {
		return ((s == null) || (s.length == 0))
	}

//-->
</script>


<script language="javascript" type="text/javascript" src="ts_picker.js"></script>

</head>
<body>
</script>

<?php
include ("dbconfig.php");
$link = mysql_connect($host,$usr,$pwd)
or die("Could not connect : " . mysql_error());

//echo "Connected successfully";
mysql_select_db($db) or die("Could not select database");

if (!$_GET['update'] == '') {
$emailID = $_GET['update'];
}


/* Performing SQL query */
$query = "SELECT subject, body, admin, emailtype,service,region,startdate,starttime,endtime,duration,reason,updatetext,starttimezone,endtimezone, unknownend FROM email WHERE id = '$emailID'";
$result = mysql_query($query) or die("Query failed : " . mysql_error());

/* Printing results in HTML */
while ($myrow = mysql_fetch_row($result)) {
$subject = $myrow[0];
$emailbody = $myrow[1];
$userID = $myrow[2];
$emailtype = $myrow[3];
$service = $myrow[4];
$region = $myrow[5];
$startdate = $myrow[6];
$starttime = $myrow[7];
$endtime = $myrow[8];
$duration = $myrow[9];
$reason = $myrow[10];
$updatetext = $myrow[11];
$starttimezone = $myrow[12];
$endtimezone = $myrow[13];
$unknownend= $myrow[14];
//$service = spliti(',', $service);
//echo( 'subject  is'.$subject );
}

if ($unknownend==1)	// Clear the endtime variable if end is unknown
	$endtime= "";

if (!$userID == '') {

	$query2 = "SELECT DISTINCT username,email FROM users WHERE email = '$userID'";
	$result2 = mysql_query($query2) or die("Query failed : " . mysql_error());
	while ($myrow = mysql_fetch_row($result2)) {
		$userName = $myrow[0];
		$userEmail = $myrow[1];
	}
	mysql_free_result($result2);
}

if (!$emailID == '') {

//$query = "UPDATE useremails SET useremails.status = 'old' WHERE useremails.id = '$emailID'";

mysql_query($query);

}

/* Free resultset */
mysql_free_result($result);


/* Closing connection */
mysql_close($link);
?>
<body onLoad= FixTimeZones("<?php echo$starttimezone; ?>","<?php echo$emailtype; ?>"); >
<div id="p7swapmenu">
<form method=post action="processing/processUpdateMail.php" name="frmMail" id="frmMail">
<input type="hidden" name="service" value="">

<input type="hidden" name="region" value="">
<input type="hidden" name="emailIcon" value="">
<input type="hidden" name="emailID" value="<?PHP echo $emailID; ?>">
<input type="hidden" name="fromemail" value="<?php echo $HTTP_COOKIE_VARS["cookemail"] ?>">
<input type="hidden" name="fromname" value="Stratos Admin">
<input type="hidden" name="appduration" value="">
 <table>
   <tr>
     <td colspan="2">From:  </td>
     <td colspan="2">Stratos Admin < operations@stratosglobal.com></td>

   </tr>

   <tr>
      <td colspan="2"><label for="bcc">Subject:  </label></td>
    
<!--
//<?php
//include ("dbconfig.php");
//$link = mysql_connect($host,$usr,$pwd)
//or die("Could not connect : " . mysql_error());
//
////echo "Connected successfully";
//mysql_select_db($db) or die("Could not select database");
//
//* Performing SQL query */
//$query = "SELECT DISTINCT class FROM outageclass ORDER BY class";
//$result = mysql_query($query) or die("Query failed : " . mysql_error());
//$adminnames ='';
///* Printing results in HTML */
//while ($myrow = mysql_fetch_row($result)) {
//	$classVal = $myrow[0];
//	if( strpos( $subject, $classVal) != false) {
//		printf("<td>". $classVal . "</td>");
//		echo( '<input type="hidden" name="subject" value="'.$classVal.'">'  );
//	}
//}
//
//
//
///* Free resultset */
//mysql_free_result($result);
//
///* Closing connection */
//mysql_close($link);
//?>
           </select>
-->
<?php
	printf("<td>". $subject . "</td>");
	echo( '<input type="hidden" name="subject" value="'.$subject.'">'  );
?>


</td>
   </tr>

   <tr>
        <td colspan="2">Severity:  </td>
        <td colspan="2"><input type="radio" name="icontype" value="Critical"><img src="images/icon_critical.gif" width="16" height="16" border="0" alt="Critical">&nbsp;Critical<br><input type="radio" name="icontype" value="Major"><img src="images/icon_major.gif" width="16" height="16" border="0" alt="Major">&nbsp;Major<br><input type="radio" name="icontype" value="Minor"><img src="images/icon_minor.gif" width="16" height="16" border="0" alt="Minor">&nbsp;Minor<br><input type="radio" name="icontype" value="Warning"><img src="images/icon_warning.gif" width="16" height="16" border="0" alt="Warning">&nbsp;Warning<br><input type="radio" name="icontype" value="Normal"><img src="images/icon_normal.gif" width="16" height="16" border="0" alt="Normal">&nbsp;Normal<br><input type="radio" name="icontype" value="Informational"><img src="images/icon_unknown.gif" width="16" height="16" border="0" alt="Unknown">&nbsp;Informational</td>

   </tr>

   <tr>
     <td colspan="2"><label for="message">Message:  </label></td>
     <td colspan="2"> Please be advised of an interruption to the following Stratos service(s):<br>
<?php
include ("dbconfig.php");
$link = mysql_connect($host,$usr,$pwd)
or die("Could not connect : " . mysql_error());

//echo "Connected successfully";
mysql_select_db($db) or die("Could not select database");

/* Performing SQL query */
$query = "SELECT DISTINCT id,service FROM stratosservices ORDER BY service";
$result = mysql_query($query) or die("Query failed : " . mysql_error());
$adminnames ='';
/* Printing results in HTML */
while ($myrow = mysql_fetch_row($result)) {
	$serviceVal = $myrow[1];
	$services = strstr($service,$serviceVal);
	if( $services == '') {
		printf("<input type=\"checkbox\" name=\"services\" value=\"%s\"> %s\n<br>",$myrow[1], $myrow[1]);
	}
	else {
		printf("<input type=\"checkbox\" name=\"services\" value=\"%s\" checked> %s\n<br>",$myrow[1], $myrow[1]);
	}

}
//$adminnames = str_replace(";", " ",$adminnames);
printf("<br>");
printf("Region(s) Affected: <br>");
/* Performing SQL query */
$query = "SELECT DISTINCT regions FROM regionsaffected ORDER BY regions";
$result = mysql_query($query) or die("Query failed : " . mysql_error());
$adminnames ='';
/* Printing results in HTML */
while ($myrow = mysql_fetch_row($result)) {
$regionsVal = $myrow[0];
$regions = strstr($region,$regionsVal);
	if( $regions == '') {
		printf("<input type=\"checkbox\" name=\"regions\" value=\"%s\"> %s\n<br>",$myrow[0], $myrow[0]);
	}
	else {
		printf("<input type=\"checkbox\" name=\"regions\" value=\"%s\" checked> %s\n<br>",$myrow[0], $myrow[0]);
	}
}
printf("<br>");
printf("<br>");
printf("Interruption Window Start Date and Time: <input type=\"text\" id=\"demo1\" name=\"startdate\" value=\"$startdate\" size=20>&nbsp;&nbsp;<a href=\"javascript:show_calendar('document.frmMail.startdate', document.frmMail.startdate.value)\"><img src=\"images/cal.gif\" width=\"16\" height=\"16\" border=\"0\" alt=\"Pick a date\"></a>&nbsp;&nbsp;");
printf("<select name=\"starttimezone\" onChange=\"StartTZChanged();\"><option value=\"UTC\">UTC</option><option value=\"ADT\">ADT</option><option value=\"AKST\">AKST</option><option value=\"AKDT\">AKDT</option><option value=\"AST\">AST</option><option value=\"BST\">BST</option><option value=\"CDT\">CDT</option><option value=\"CET\">CET</option><option value=\"CEST\">CEST</option><option value=\"CST\">CST</option><option value=\"CXT\">CXT</option><option value=\"EDT\">EDT</option><option value=\"EET\">EET</option><option value=\"EEST\">EEST</option><option value=\"EST\">EST</option><option value=\"GMT\">GMT</option><option value=\"HAST\">HAST</option><option value=\"HADT\">HADT</option><option value=\"IST\">IST</option><option value=\"MDT\">MDT</option><option value=\"MST\">MST</option><option value=\"NDT\">NDT</option><option value=\"NFT\">NFT</option><option value=\"NST\">NST</option><option value=\"PDT\">PDT</option><option value=\"PST\">PST</option><option value=\"WET\">WET</option><option value=\"WEST\">WEST</option><option value=\"WST\">WST</option>");
printf("</select><br>");
printf("<br>");
printf("Interruption Window End Date and Time: <input type=\"text\" id=\"demo2\" name=\"endtime\" value=\"$endtime\" size=20>&nbsp;&nbsp;<a href=\"javascript:if (!document.frmMail.unknownend.checked)show_calendar('document.frmMail.endtime', document.frmMail.endtime.value)\"><img src=\"images/cal.gif\" width=\"16\" height=\"16\" border=\"0\" alt=\"Pick a date\"></a>&nbsp;&nbsp;");
printf("<select name=\"endtimezone\" onChange=\"EndTZChanged();\"><option value=\"UTC\">UTC</option><option value=\"ADT\">ADT</option><option value=\"AKST\">AKST</option><option value=\"AKDT\">AKDT</option><option value=\"AST\">AST</option><option value=\"BST\">BST</option><option value=\"CDT\">CDT</option><option value=\"CET\">CET</option><option value=\"CEST\">CEST</option><option value=\"CST\">CST</option><option value=\"CXT\">CXT</option><option value=\"EDT\">EDT</option><option value=\"EET\">EET</option><option value=\"EEST\">EEST</option><option value=\"EST\">EST</option><option value=\"GMT\">GMT</option><option value=\"HAST\">HAST</option><option value=\"HADT\">HADT</option><option value=\"IST\">IST</option><option value=\"MDT\">MDT</option><option value=\"MST\">MST</option><option value=\"NDT\">NDT</option><option value=\"NFT\">NFT</option><option value=\"NST\">NST</option><option value=\"PDT\">PDT</option><option value=\"PST\">PST</option><option value=\"WET\">WET</option><option value=\"WEST\">WEST</option><option value=\"WST\">WST</option>");
printf("</select><br>");
printf("&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp");
printf("&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp;");
if ($unknownend == 1)
	printf("or <input type=checkbox name=unknownend onclick='javascript:document.frmMail.endtime.value=\"\"' checked></input>Unknown");

else
	printf("or <input type=checkbox name=unknownend onclick=javascript:document.frmMail.endtime.value=\"\"></input>Unknown");

printf("<br>");
printf("<br>");
printf("<br>");
//printf("Approximate Duration: ");
//printf("<select name=\"appduration\"><option value=\"\">Select Duration</option><option value=\"Unknown\">Unknown</option><option value=\"Less than 1 hour\">Less than 1 hour</option>");
//for ($i = 1; $i < 25; $i++) {
//	if ( $i == 1 )
//		$timesufix= ' hour';
//	else
//		$timesufix= ' hours';
//
//	$durationVal = $i.$timesufix;
//		if( $durationVal == $duration) {
//			printf("<option value=\"$i$timesufix\" selected>$i$timesufix</option><br/>");
//		}
//		else {
//			printf("<option value=\"$i$timesufix\">$i$timesufix</option><br/>");
//	}
//}
//printf("</select><br>");
printf("<br>");
printf("Reason: <br>");
printf("<br>");
/* Free resultset */
mysql_free_result($result);

/* Closing connection */
mysql_close($link);
?>
     <textarea name="mailtext1" cols="55" rows="5" OnSelect="StoreCaret(this);" OnClick="StoreCaret(this);" OnKeyUp="StoreCaret(this);" OnDBLClick="StoreCaret(this);"><?PHP echo $reason; ?></textarea>
	 <br><A HREF="#" onMouseOver="changeImages('imgBold', 'imgBoldon');window.status='Bold';return true;" onMouseOut="window.status='';changeImages('imgBold', 'imgBoldoff')" OnClick="InsertAtCursor(document.frmMail.mailtext1,'<b>','</b>','Bold');return false;"><img src="images/bold_off.gif" NAME="imgBold" WIDTH=25 HEIGHT=25 BORDER="0" ALT="Bold"><A HREF="#" onMouseOver="changeImages('imgItalic', 'imgItalicon');window.status='Italic';return true;" onMouseOut="window.status='';changeImages('imgItalic', 'imgItalicoff')" OnClick="InsertAtCursor(document.frmMail.mailtext1,'<i>','</i>','Italic');return false;"><img src="images/italic_off.gif" NAME="imgItalic" WIDTH=25 HEIGHT=25 BORDER="0" ALT="Italic"><A HREF="#" onMouseOver="changeImages('imgUnderline', 'imgUnderlineon');window.status='Underline';return true;" onMouseOut="window.status='';changeImages('imgUnderline', 'imgUnderlineoff')" OnClick="InsertAtCursor(document.frmMail.mailtext1,'<u>','</u>','Underline');return false;"><img src="images/underline_off.gif" NAME="imgUnderline" WIDTH=27 HEIGHT=25 BORDER="0" ALT="Underline"><A HREF="#" onMouseOver="changeImages('imgOrderedList', 'imgOrderedListon');window.status='Ordered List';return true;" onMouseOut="window.status='';changeImages('imgOrderedList', 'imgOrderedListoff')" OnClick="InsertLists(document.frmMail.mailtext1,'<ol>','</ol>','<li>','Ordered List');return false;"><img src="images/orderedlist_off.gif" NAME="imgOrderedList" WIDTH=27 HEIGHT=25 BORDER="0" ALT="Ordered List"><A HREF="#" onMouseOver="changeImages('imgUnorderedList', 'imgUnorderedListon');window.status='Unordered List';return true;" onMouseOut="window.status='';changeImages('imgUnorderedList', 'imgUnorderedListoff')" OnClick="InsertLists(document.frmMail.mailtext1,'<ul>','</ul>','<li>','Unordered List');return false;"><img src="images/unorderedlist_off.gif" NAME="imgUnorderedList" WIDTH=25 HEIGHT=25 BORDER="0" ALT="Unordered List"><A HREF="#" onMouseOver="changeImages('imgAlignLeft', 'imgAlignLefton');window.status='Align Left';return true;" onMouseOut="window.status='';changeImages('imgAlignLeft', 'imgAlignLeftoff')" OnClick="InsertAtCursor(document.frmMail.mailtext1,'<div align=left>','</div>','Align Left');return false;"><img src="images/alignleft_off.gif" NAME="imgAlignLeft" WIDTH=27 HEIGHT=25 BORDER="0" ALT="Align Left"><A HREF="#" onMouseOver="changeImages('imgAlignCenter', 'imgAlignCenteron');window.status='Align Center';return true;" onMouseOut="window.status='';changeImages('imgAlignCenter', 'imgAlignCenteroff')" OnClick="InsertAtCursor(document.frmMail.mailtext1,'<center>','</center>','Align Center');return false;"><img src="images/aligncenter_off.gif" NAME="imgAlignCenter" WIDTH=25 HEIGHT=25 BORDER="0" ALT="Align Center"><A HREF="#" onMouseOver="changeImages('imgAlignRight', 'imgAlignRighton');window.status='Align Right';return true;" onMouseOut="window.status='';changeImages('imgAlignRight', 'imgAlignRightoff')" OnClick="InsertAtCursor(document.frmMail.mailtext1,'<div align=right>','</div>','Align Right');return false;" ><img src="images/alignright_off.gif" NAME="imgAlignRight" WIDTH=25 HEIGHT=25 BORDER="0" ALT="Align Right"></a>
		<br>

     <br>Update: <br><br><textarea name="mailtext2" cols="55" rows="5" OnSelect="StoreCaret(this);" OnClick="StoreCaret(this);" OnKeyUp="StoreCaret(this);" OnDBLClick="StoreCaret(this);"><?php echo $updatetext ?></textarea>
	 <br><A HREF="#" onMouseOver="changeImages('imgBold', 'imgBoldon');window.status='Bold';return true;" onMouseOut="window.status='';changeImages('imgBold', 'imgBoldoff')" OnClick="InsertAtCursor(document.frmMail.mailtext2,'<b>','</b>','Bold');return false;"><img src="images/bold_off.gif" NAME="imgBold" WIDTH=25 HEIGHT=25 BORDER="0" ALT="Bold"><A HREF="#" onMouseOver="changeImages('imgItalic', 'imgItalicon');window.status='Italic';return true;" onMouseOut="window.status='';changeImages('imgItalic', 'imgItalicoff')" OnClick="InsertAtCursor(document.frmMail.mailtext2,'<i>','</i>','Italic');return false;"><img src="images/italic_off.gif" NAME="imgItalic" WIDTH=25 HEIGHT=25 BORDER="0" ALT="Italic"><A HREF="#" onMouseOver="changeImages('imgUnderline', 'imgUnderlineon');window.status='Underline';return true;" onMouseOut="window.status='';changeImages('imgUnderline', 'imgUnderlineoff')" OnClick="InsertAtCursor(document.frmMail.mailtext2,'<u>','</u>','Underline');return false;"><img src="images/underline_off.gif" NAME="imgUnderline" WIDTH=27 HEIGHT=25 BORDER="0" ALT="Underline"><A HREF="#" onMouseOver="changeImages('imgOrderedList', 'imgOrderedListon');window.status='Ordered List';return true;" onMouseOut="window.status='';changeImages('imgOrderedList', 'imgOrderedListoff')" OnClick="InsertLists(document.frmMail.mailtext2,'<ol>','</ol>','<li>','Ordered List');return false;"><img src="images/orderedlist_off.gif" NAME="imgOrderedList" WIDTH=27 HEIGHT=25 BORDER="0" ALT="Ordered List"><A HREF="#" onMouseOver="changeImages('imgUnorderedList', 'imgUnorderedListon');window.status='Unordered List';return true;" onMouseOut="window.status='';changeImages('imgUnorderedList', 'imgUnorderedListoff')" OnClick="InsertLists(document.frmMail.mailtext2,'<ul>','</ul>','<li>','Unordered List');return false;"><img src="images/unorderedlist_off.gif" NAME="imgUnorderedList" WIDTH=25 HEIGHT=25 BORDER="0" ALT="Unordered List"><A HREF="#" onMouseOver="changeImages('imgAlignLeft', 'imgAlignLefton');window.status='Align Left';return true;" onMouseOut="window.status='';changeImages('imgAlignLeft', 'imgAlignLeftoff')" OnClick="InsertAtCursor(document.frmMail.mailtext2,'<div align=left>','</div>','Align Left');return false;"><img src="images/alignleft_off.gif" NAME="imgAlignLeft" WIDTH=27 HEIGHT=25 BORDER="0" ALT="Align Left"><A HREF="#" onMouseOver="changeImages('imgAlignCenter', 'imgAlignCenteron');window.status='Align Center';return true;" onMouseOut="window.status='';changeImages('imgAlignCenter', 'imgAlignCenteroff')" OnClick="InsertAtCursor(document.frmMail.mailtext2,'<center>','</center>','Align Center');return false;"><img src="images/aligncenter_off.gif" NAME="imgAlignCenter" WIDTH=25 HEIGHT=25 BORDER="0" ALT="Align Center"><A HREF="#" onMouseOver="changeImages('imgAlignRight', 'imgAlignRighton');window.status='Align Right';return true;" onMouseOut="window.status='';changeImages('imgAlignRight', 'imgAlignRightoff')" OnClick="InsertAtCursor(document.frmMail.mailtext2,'<div align=right>','</div>','Align Right');return false;" ><img src="images/alignright_off.gif" NAME="imgAlignRight" WIDTH=25 HEIGHT=25 BORDER="0" ALT="Align Right"></a></td>
   </tr>
   <tr>
     <td colspan="4"><center><input type="button" name="Submit" value="Send" OnClick="ProcessForm();" tabindex="8" />&nbsp;&nbsp;<input type="button" value="Preview" onClick="Preview(this.form);">&nbsp;&nbsp;<input type="reset" value="Reset"></center></td>
   </tr>
 </table>
</form>
</div>
</body>

</html>
