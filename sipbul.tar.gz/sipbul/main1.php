<html>
<head>

<link rel="STYLESHEET" type="text/css" href="styles.css">
<link rel="STYLESHEET" type="text/css" href="tree.css">

<script language="JavaScript">
<!--

	function ProcessForm(){
		var testresults;
		var strSubmitMessage = '';
		var blnStopSubmission = false;

		//Validate Launch Date
		if (isEmpty(document.frmMail.name.value)) {
			blnStopSubmission = true;
			strSubmitMessage = strSubmitMessage + '\      Please Enter Admin Name\n';
		}

		// the following expression must be all on one line...
		var goodEmail = document.frmMail.email.value.match(/\b(^(\S+@).+((\.com)|(\.net)|(\.edu)|(\.mil)|(\.gov)|(\.org)|(\..{2,2}))$)\b/gi);
		if (goodEmail){
		   //good = true
		}
		else {
		   //alert('Please enter a valid e-mail address.')
		   blnStopSubmission = true;
		   strSubmitMessage = strSubmitMessage + '\      Please enter a valid e-mail address\n';
   		}

		//Submit the form
		if(!blnStopSubmission) {
			document.frmMail.submit();
		}
		else {
			alert(strSubmitMessage);
		}
	}

	//Check whether string s is empty.
	function isEmpty(s) {
		return ((s == null) || (s.length == 0))
	}

function ViewEmail(id,userid)
	{
	//alert(id);
	setup2 = 'toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=no,copyhistory=no,width=680,height=550';
	pop = window.open ("viewEmail.php?emailID="+ id + "&userid="+ userid,"pop",setup2);

}


//-->
</script>

</head>
<body>
<div id="p7swapmenu">
<form method=post action="" name="frmMail" id="frmMail">
<table>
   <tr align=\"top\">
<?php
include ("dbconfig.php");
$link = mysql_connect($host,$usr,$pwd)
or die("Could not connect : " . mysql_error());

//echo "Connected successfully";
mysql_select_db($db) or die("Could not select database");

$UserNam = $HTTP_COOKIE_VARS["cookname"];
$UserEmailid = $HTTP_COOKIE_VARS["cookemail"];
$UserType = 'admin';
//$UserNam = $_SESSION['username'];


if (!$_GET['userID'] == '') {
	$UserID = $_GET['userID'];
	echo $UserID.' Mail Box<br><br>';
	/* Performing SQL query */
	//$query = "SELECT id,subject,admin,date FROM email ORDER BY date DESC";
	$query = "SELECT useremails.id, useremails.status ,email.id, email.subject, email.admin, email.date, email.emailtype, email.emailupdate,useremails.userid FROM useremails INNER JOIN email ON useremails.emailid = email.id WHERE useremails.userid = '$UserID' ORDER BY date DESC";
	$result = mysql_query($query) or die("Query failed : " . mysql_error());

	$queryG = "SELECT DISTINCT groupname FROM groups WHERE userid = '$UserID'";
	$resultG = mysql_query($queryG) or die("Query failed : " . mysql_error());

	while ($myrowG = mysql_fetch_row($resultG)) {
		if ($groupName == '') {
			$groupName = $myrowG[0];
		}
		else {
			$groupName = $groupName.', '.$myrowG[0];
		}
	}

	/* Printing results in HTML */
	printf("<td width=560 colspan=\"2\"><label for=\"name\"><b>Subject</b></label></td>");
	printf("<td width=10 colspan=\"2\"><label for=\"name\"><b>Service Affected</b></label></td>");
	printf("<td colspan=\"2\"><label for=\"name\"><b>Received</b></label></td>");
	printf("<td colspan=\"2\"><label for=\"name\"><b>Action</b></label></td></tr>");
	//printf("<tr><td colspan=\"2\" align=\"top\">");
	while ($myrow = mysql_fetch_row($result)) {
		$status = $myrow[1];
		$emailupdate = $myrow[7];
		if ($status == 'new' && $emailupdate == 'yes') {
			printf("<tr><td colspan=\"2\"><label for=\"name\"><img src=\"images/icon_%s.gif\" width=\"16\" height=\"16\" border=\"0\" alt=\"%s\"></a>&nbsp;&nbsp;<a href=\"javascript:ViewEmail(%s,%s);\"><b>%s</a><img src=\"icon-highimportance.gif\"><font size=\"1\" color=\"blue\">updated</font></label></td><td colspan=\"2\"><label for=\"name\">$groupName</label></td><td colspan=\"2\"><label for=\"name\">%s</label></td><td colspan=\"2\"><label for=\"name\"><a href=\"processing/processDeleteEmail.php?userID=$UserID&delete=%s\">delete</a></label></td></tr>", $myrow[6],$myrow[6],$myrow[2],$myrow[8],$myrow[3],$myrow[5],$myrow[0]);
		}
		elseif ($status == 'new') {
			printf("<tr><td colspan=\"2\"><label for=\"name\"><img src=\"images/icon_%s.gif\" width=\"16\" height=\"16\" border=\"0\" alt=\"%s\"></a>&nbsp;&nbsp;<a href=\"javascript:ViewEmail(%s,%s);\"><b>%s</b></a></label></td><td colspan=\"2\"><label for=\"name\">$groupName</label></td><td colspan=\"2\"><label for=\"name\">%s</label></td><td colspan=\"2\"><label for=\"name\"><a href=\"processing/processDeleteEmail.php?userID=$UserID&delete=%s\">delete</a></label></td></tr>", $myrow[6],$myrow[6],$myrow[2],$myrow[8],$myrow[3],$myrow[5],$myrow[0]);
		}
		elseif ($emailupdate == 'yes') {
			printf("<tr><td colspan=\"2\"><label for=\"name\"><img src=\"images/icon_%s.gif\" width=\"16\" height=\"16\" border=\"0\" alt=\"%s\"></a>&nbsp;&nbsp;<a href=\"javascript:ViewEmail(%s,%s);\">%s&nbsp;</a><img src=\"icon-highimportance.gif\"><font size=\"1\" color=\"blue\">updated</font></label></td><td colspan=\"2\"><label for=\"name\">$groupName</label></td><td colspan=\"2\"><label for=\"name\">%s</label></td><td colspan=\"2\"><label for=\"name\"><a href=\"processing/processDeleteEmail.php?userID=$UserID&delete=%s\">delete</a></label></td></tr>", $myrow[6],$myrow[6],$myrow[2],$myrow[8],$myrow[3],$myrow[5],$myrow[0]);
		}
		else {
			printf("<tr><td colspan=\"2\"><label for=\"name\"><img src=\"images/icon_%s.gif\" width=\"16\" height=\"16\" border=\"0\" alt=\"%s\"></a>&nbsp;&nbsp;<a href=\"javascript:ViewEmail(%s,%s);\">%s</a></label></td><td colspan=\"2\"><label for=\"name\">$groupName</label></td><td colspan=\"2\"><label for=\"name\">%s</label></td><td colspan=\"2\"><label for=\"name\"><a href=\"processing/processDeleteEmail.php?userID=$UserID&delete=%s\">delete</a></label></td></tr>", $myrow[6],$myrow[6],$myrow[2],$myrow[8],$myrow[3],$myrow[5],$myrow[0]);
		}
	}

	/* Free resultset */
	mysql_free_result($result);


}
else {
	/* Performing SQL query */
	$query = "SELECT id,subject,admin,date,emailtype,emailupdate,service FROM email WHERE admin = '$UserEmailid' ORDER BY date DESC";
	$result = mysql_query($query) or die("Query failed : " . mysql_error());
	echo 'Welcome '.$UserNam.'!';
	/* Printing results in HTML */
	printf("<td width=560 colspan=\"2\"><label for=\"name\"><b>Subject</b></label></td>");
	printf("<td colspan=\"2\"><label for=\"name\"><b>Service Affected</b></label></td>");
	printf("<td colspan=\"2\"><label for=\"name\"><b>Received</b></label></td>");
	printf("<td colspan=\"2\"><label for=\"name\"><b>Action</b></label></td></tr>");
	//printf("<tr><td colspan=\"2\" align=\"top\">");

	while ($myrow = mysql_fetch_row($result)) {
		$emailupdate = $myrow[5];
		if( $emailupdate == 'yes') {
			printf("<tr><td colspan=\"2\"><label for=\"name\"><img src=\"images/icon_%s.gif\" width=\"16\" height=\"16\" border=\"0\" alt=\"%s\"></a>&nbsp;&nbsp;<a href=\"javascript:ViewEmail(%s,'admin');\">%s</a>&nbsp;<img src=\"icon-highimportance.gif\"><font size=\"1\" color=\"blue\">updated</font></label></td><td colspan=\"2\"><label for=\"name\">%s</label></td><td colspan=\"2\"><label for=\"name\">%s</label></td><td colspan=\"2\"><label for=\"name\"><a href=\"updateEmail.php?update=%s\">update</a> | <a href=\"processing/processDeleteEmail.php?delete=%s\">delete</a></label></td></tr>", $myrow[4],$myrow[4],$myrow[0],$myrow[1],$myrow[6],$myrow[3],$myrow[0],$myrow[0]);
		}
		else {
			printf("<tr><td colspan=\"2\"><label for=\"name\"><img src=\"images/icon_%s.gif\" width=\"16\" height=\"16\" border=\"0\" alt=\"%s\"></a>&nbsp;&nbsp;<a href=\"javascript:ViewEmail(%s,'admin');\">%s</a></label></td><td colspan=\"2\"><label for=\"name\">%s</label></td><td colspan=\"2\"><label for=\"name\">%s</label></td><td colspan=\"2\"><label for=\"name\"><a href=\"updateEmail.php?update=%s\">update</a> | <a href=\"processing/processDeleteEmail.php?delete=%s\">delete</a></label></td></tr>", $myrow[4],$myrow[4],$myrow[0],$myrow[1],$myrow[6],$myrow[3],$myrow[0],$myrow[0]);
		}
	}
	/* Free resultset */
	mysql_free_result($result);

}
/* Closing connection */
mysql_close($link);
?>

   </tr>
</table>

</form>
</div>
</body>
</html>