<html>
<head>

<link rel="STYLESHEET" type="text/css" href="styles.css">
<link rel="STYLESHEET" type="text/css" href="tree.css">

<script language="JavaScript">
<!--

	function ProcessForm(){
		var testresults;
		var strSubmitMessage = '';
		var blnStopSubmission = false;

		//Validate Launch Date
		if (isEmpty(document.frmMail.name.value)) {
			blnStopSubmission = true;
			strSubmitMessage = strSubmitMessage + '\      Please Enter Outage Class\n';
		}

// jpr 5-9-05 No need to look, icons not associated with Outage Class Anymore
//		for (var i=0;i<document.frmMail.icontype.length;i++) {
//			if (document.frmMail.icontype[i].checked) {
//				document.frmMail.emailIcon.value = document.frmMail.icontype[i].value
//			}
//
//		}
//
//		if (isEmpty(document.frmMail.emailIcon.value)) {
//			blnStopSubmission = true;
//			strSubmitMessage = strSubmitMessage + '\      Please Select a Outage Type\n';
//		}
		//alert(document.frmMail.emailIcon.value);

		//Submit the form
		if(!blnStopSubmission) {
			document.frmMail.submit();
		}
		else {
			alert(strSubmitMessage);
		}
	}

	//Check whether string s is empty.
	function isEmpty(s) {
		return ((s == null) || (s.length == 0))
	}




//-->
</script>

</head>
<body>
<div id="p7swapmenu">
<form method=post action="processing/processOutage.php" name="frmMail" id="frmMail">
<!-- jpr 5-9-05 not passing emailIcon anymore
<input type="hidden" name="emailIcon" value="">
-->
 <table>
   <tr>
     <td colspan="2">Outage Class:  </td>
     <td colspan="2"> <input type="text" name="name" size=50></td>

   </tr>
<!--	jpr 5-9-05 Icons not used for this anymore
   <tr>
        <td colspan="2">Outage Type:  </td>
        <td colspan="2"><input type="radio" name="icontype" value="critical"><img src="images/icon_critical.gif" width="16" height="16" border="0" alt="Critical">&nbsp;&nbsp;&nbsp;<input type="radio" name="icontype" value="major"><img src="images/icon_major.gif" width="16" height="16" border="0" alt="Major">&nbsp;&nbsp;&nbsp;<input type="radio" name="icontype" value="minor"><img src="images/icon_minor.gif" width="16" height="16" border="0" alt="Minor">&nbsp;&nbsp;&nbsp;<input type="radio" name="icontype" value="warning"><img src="images/icon_warning.gif" width="16" height="16" border="0" alt="Warning">&nbsp;&nbsp;&nbsp;<input type="radio" name="icontype" value="normal"><img src="images/icon_normal.gif" width="16" height="16" border="0" alt="Normal">&nbsp;&nbsp;&nbsp;<input type="radio" name="icontype" value="unknown"><img src="images/icon_unknown.gif" width="16" height="16" border="0" alt="Unknown"></td>

   </tr>
-->

   <tr>
        <td colspan="4"><center><input type="button" name="Submit" value="Submit" OnClick="ProcessForm();" tabindex="8" />&nbsp;&nbsp;<input type="reset" value="Reset"></center></td>
   </tr>
</table>
<p><p>
<table>
   <tr align=\"top\">
<?php
include ("dbconfig.php");
$link = mysql_connect($host,$usr,$pwd)
or die("Could not connect : " . mysql_error());

//echo "Connected successfully";
mysql_select_db($db) or die("Could not select database");

/* Performing SQL query */
$query = "SELECT id,class,adminid,outagetype FROM outageclass ORDER BY class";
$result = mysql_query($query) or die("Query failed : " . mysql_error());

/* Printing results in HTML */
printf("<td colspan=\"2\"><label for=\"name\"><b>Outage Class</b></label></td>");
printf("<td colspan=\"2\"><label for=\"name\"><b>Action</b></label></td></tr>");
//printf("<tr><td colspan=\"2\" align=\"top\">");
while ($myrow = mysql_fetch_row($result)) {

		printf("<tr><td colspan=\"2\"><label for=\"name\"></a><label for=\"name\">%s</label></td><td colspan=\"2\"><label for=\"name\"><a href=\"processing/processOutage.php?delete=%s\">delete</a></label></td></tr>",$myrow[1],$myrow[0]);
}

/* Free resultset */
mysql_free_result($result);

/* Closing connection */
mysql_close($link);
?>

   </tr>
</table>

</form>
</div>
</body>
</html>
