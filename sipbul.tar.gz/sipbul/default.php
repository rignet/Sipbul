<html>
<link rel="STYLESHEET" type="text/css" href="styles.css">
<link rel="STYLESHEET" type="text/css" href="tree.css">
<frameset cols="25%,75%">

  <frame src="leftNav.php" name="left">
  <frame src="main.php" name="main">

</frameset>

</html>