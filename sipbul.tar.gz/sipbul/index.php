<html>
<script language="JavaScript">
<!--

	function ProcessForm(){
		var testresults;
		var strSubmitMessage = '';
		var blnStopSubmission = false;


		// the following expression must be all on one line...
		var goodEmail = document.frmMail.email.value.match(/\b(^(\S+@).+((\.com)|(\.net)|(\.edu)|(\.mil)|(\.gov)|(\.org)|(\..{2,2}))$)\b/gi);
		if (goodEmail){
		   //good = true
		}
		else {
		   //alert('Please enter a valid e-mail address.')
		   blnStopSubmission = true;
		   strSubmitMessage = strSubmitMessage + '\      Please enter a valid e-mail address\n';
   		}

   		//Validate Launch Date
				if (isEmpty(document.frmMail.password.value)) {
					blnStopSubmission = true;
					strSubmitMessage = strSubmitMessage + '\      Please Enter Password\n';
		}

		//Submit the form
		if(!blnStopSubmission) {
			document.frmMail.submit();
		}
		else {
			alert(strSubmitMessage);
		}
	}

	//Check whether string s is empty.
	function isEmpty(s) {
		return ((s == null) || (s.length == 0))
	}




//-->
</script>

</head>

<?PHP
if($_GET['login'] == 'failed') {
	echo "<font color=red>Invalid Login/Password!!</font>";
}
?>

<body style="background-color: #FFFFFF;font-family: Arial, Helvetica, sans-serif;font-size: 80%;margin: 200px 0 0 200px;background-image: url(scm01_pbg.gif);background-repeat: repeat-x;">
<td width="858"><img src="images/headerbar2.jpg" width="858" height="21" border="0" align="middle"alt=""></td>
<p><p>
<p><p>
<div style="background-color: #FFFFFF;border: 0px solid; border-color: #E4E9D8 #99A189 #99A189 #E4E9D8;left: 80px;padding: 6px;position: right;top: 40px;width: 140px;">
<form method=post action="processing/processLogin.php" name="frmMail" id="frmMail">
<center>
<p><p><p><p><p>
  <table style="background-color: #FFFFFF; color: #000000; width: 200px; border: 0px solid #FFFFFF; vertical-align: top; font: 11px Verdana, Geneva, Arial, Helvetica, sans-serif;">
   <tr>
     <td colspan="2">User name:  </td>
     <td colspan="2"> <input type="text" name="email" size=30></td>
   </tr>
   <tr>
     <td colspan="2">Password:  </td>
     <td colspan="2"> <input type="password" name="password" size=20> </td>
   </tr>
   <tr>
        <td colspan="4"><center><input type="submit" name="Submit" value="Submit" OnClick="ProcessForm();" tabindex="8"/>&nbsp;&nbsp;<input type="reset" value="Reset"></center></td>
   </tr>
</table>
</center>
</form>
</div>
</body>
</html>
