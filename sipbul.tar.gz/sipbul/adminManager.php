<html>
<head>

<link rel="STYLESHEET" type="text/css" href="styles.css">
<link rel="STYLESHEET" type="text/css" href="tree.css">

<script language="JavaScript">
<!--

	function ProcessForm(){
		var testresults;
		var strSubmitMessage = '';
		var blnStopSubmission = false;

		//Validate Launch Date
		if (isEmpty(document.frmMail.name.value)) {
			blnStopSubmission = true;
			strSubmitMessage = strSubmitMessage + '\      Please Enter Admin Name\n';
		}

		// the following expression must be all on one line...
		var goodEmail = document.frmMail.email.value.match(/\b(^(\S+@).+((\.com)|(\.net)|(\.edu)|(\.mil)|(\.gov)|(\.org)|(\..{2,2}))$)\b/gi);
		if (goodEmail){
		   //good = true
		}
		else {
		   //alert('Please enter a valid e-mail address.')
		   blnStopSubmission = true;
		   strSubmitMessage = strSubmitMessage + '\      Please enter a valid e-mail address\n';
   		}

		//Submit the form
		if(!blnStopSubmission) {
			document.frmMail.submit();
		}
		else {
			alert(strSubmitMessage);
		}
	}

	//Check whether string s is empty.
	function isEmpty(s) {
		return ((s == null) || (s.length == 0))
	}




//-->
</script>

</head>
<body>
<div id="p7swapmenu">
<form method=post action="processing/processAddAdmin.php" name="frmMail" id="frmMail">
 <table>
   <tr>
     <td colspan="2">Admin Name:  </td>
     <td colspan="2"> <input type="text" name="name" size=30></td>
   </tr>
   <tr>
     <td colspan="2">Admin Email:  </td>
     <td colspan="2"> <input type="text" name="email" size=30> </td>
   </tr>
   <tr>
        <td colspan="2">Login Password:  </td>
        <td colspan="2"> <input type="password" name="password" size=20> </td>
   </tr>
   <tr>
	<td colspan="2">Admin Type:  </td>
	<td colspan="2"> <select name="admintype"><option value="admin">Level 1 Admin</option>
							<option value="super">Level 2 Admin</option>
					</select>
	</td>
   </tr>
   <tr>
        <td colspan="4"><center><input type="button" name="Submit" value="Submit" OnClick="ProcessForm();" tabindex="8" />&nbsp;&nbsp;<input type="reset" value="Reset"></center></td>
   </tr>
</table>
<p><p>
<table>
   <tr align=\"top\">
<?php
include ("dbconfig.php");
$link = mysql_connect($host,$usr,$pwd)
or die("Could not connect : " . mysql_error());

//echo "Connected successfully";
mysql_select_db($db) or die("Could not select database");

/* Performing SQL query */
$query = "SELECT id,adminname,email,admintype FROM admin ORDER BY adminname";
$result = mysql_query($query) or die("Query failed : " . mysql_error());

/* Printing results in HTML */
printf("<td colspan=\"2\"><label for=\"name\"><b>Admin Name</b></label></td>");
printf("<td colspan=\"2\"><label for=\"name\"><b>Admin Email</b></label></td>");
printf("<td colspan=\"2\"><label for=\"name\"><b>Admin Type</b></label></td>");
printf("<td colspan=\"2\"><label for=\"name\"><b>Action</b></label></td></tr>");
//printf("<tr><td colspan=\"2\" align=\"top\">");
while ($myrow = mysql_fetch_row($result)) {
	$admintype = $myrow[3];
	if ($admintype == 'super') {
		$admintypeVal = 'Level 2 Admin';
	}
	if ($admintype == 'admin') {
		$admintypeVal = 'Level 1 Admin';
	}
	printf("<tr><td colspan=\"2\"><label for=\"name\">%s</label></td><td colspan=\"2\"><label for=\"name\">%s</label></td><td colspan=\"2\"><label for=\"name\">$admintypeVal</label></td><td colspan=\"2\"><label for=\"name\"><a href=\"processing/processAddAdmin.php?delete=%s\">delete</a> | <a href=\"editAdmin.php?edit=%s\">edit</a></label></td></tr>", $myrow[1],$myrow[2],$myrow[0],$myrow[0]);
}

/* Free resultset */
mysql_free_result($result);

/* Closing connection */
mysql_close($link);
?>

   </tr>
</table>

</form>
</div>
</body>
</html>
