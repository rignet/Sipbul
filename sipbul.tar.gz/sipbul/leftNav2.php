<html>
<head>

<link rel="STYLESHEET" type="text/css" href="tree2.css">
<link rel="STYLESHEET" type="text/css" href="styles.css">

<script type="text/JavaScript">
<!--
function P7_swapClass(){ //v1.4 by PVII
 var i,x,tB,j=0,tA=new Array(),arg=P7_swapClass.arguments;
 if(document.getElementsByTagName){for(i=4;i<arg.length;i++){tB=document.getElementsByTagName(arg[i]);
  for(x=0;x<tB.length;x++){tA[j]=tB[x];j++;}}for(i=0;i<tA.length;i++){
  if(tA[i].className){if(tA[i].id==arg[1]){if(arg[0]==1){
  tA[i].className=(tA[i].className==arg[3])?arg[2]:arg[3];}else{tA[i].className=arg[2];}
  }else if(arg[0]==1 && arg[1]=='none'){if(tA[i].className==arg[2] || tA[i].className==arg[3]){
  tA[i].className=(tA[i].className==arg[3])?arg[2]:arg[3];}
  }else if(tA[i].className==arg[2]){tA[i].className=arg[3];}}}}
}
//-->
</script>
<script type="text/javascript">
<!--
function P7_writeStyles(op,a){ //v1.5 by PVII
if(op==0||document.getElementById){var tS="<sty"+"le type=\"text/css\">";
tS+=a+"<"+"/sty"+"le>";document.write(tS);document.close();}
}
P7_writeStyles(1,'.closed ul{ display:none;}.open ul{ display:block;}');
//-->
</script>

</head>
<body bgcolor="#0043F1">
<div>
  <ul id="menuTree">
<?php
if ($_GET['admintype'] == 'super') {
?>
  	<li class="closed"><a  href="main.php" target="main"><b>Home</b></a></li>
  	<li class="closed" id="p"><a name="anchor" href="#" onClick="P7_swapClass(1,'p','open','closed','li')"><b>Admin Manager</b></a>
	  	<ul><li><a href="adminManager.php" target="main">Admin Manager</a></li><li><a href="userManager.php" target="main">User Manager</a></li><li><a href="groupsManager.php" target="main">Groups Manager</a></li><li><a href="outageClass.php" target="main">Outage Class</a></li><li><a href="stratosServices.php" target="main">RigNet Services</a></li><li><a href="regionsAffected.php" target="main">Regions Affected</a></li><li><a href="viewArchive.php" target="main">View Message Archive</a></li><li><a href="editDisclaimer.php?nameID=<?PHP echo $_GET['adminid'] ?>" target="main">Change Disclaimer</a></li></ul>
  	</li>
<?php
}
?>

	<li class="closed"><a  href="main.php" target="main"><b>Home</b></a></li>
  	<li class="closed"><a  href="changePassword.php?nameID=<?PHP echo $_GET['adminid'] ?>" target="main"><b>Change Password</b></a></li>

  	<li class="closed"><a  href="sendMail.php" target="main"><b>Send Mail</b></a></li>
  	<li class="closed"><a  href="logout.php" target="_parent"><b>Logout</b></a></li><br><br>
<?php
include ("dbconfig.php");
$link = mysql_connect($host,$usr,$pwd)
or die("Could not connect : " . mysql_error());

//echo "Connected successfully";
mysql_select_db($db) or die("Could not select database");

/* Performing SQL query */
$query = "SELECT DISTINCT companyname FROM users ORDER BY companyname";
$result = mysql_query($query) or die("Query failed : " . mysql_error());

$count = 1;

/* Printing results in HTML */
//printf("<tr><td colspan=\"2\" align=\"top\">");
while ($myrow = mysql_fetch_row($result)) {
	if ($count == 1) {
		$comName = $myrow[0];
		printf("<li class=\"open\" id=\"p$count\"> <a name=\"anchor$count\" class=\"parent\" href=\"#anchor$count\" onClick=\"P7_swapClass(1,'p$count','open','closed','li')\">$comName</a>");
		printf("<ul>");
		$query1 = "SELECT id,username,email FROM users WHERE companyname = '$comName' ORDER BY username";
		$result1 = mysql_query($query1) or die("Query failed : " . mysql_error());
		while ($myrow1 = mysql_fetch_row($result1)) {
			printf("<li><a href=\"main.php?userID=%s\" target=\"main\">%s</a></li>",$myrow1[0],$myrow1[1]);
		}
		printf("</ul>");
		printf("</li>");
	}
	else {
		$comName = $myrow[0];
		printf("<li class=\"closed\" id=\"p$count\"> <a name=\"anchor$count\" class=\"parent\" href=\"#anchor$count\" onClick=\"P7_swapClass(1,'p$count','open','closed','li')\">$comName</a>");
		printf("<ul>");
		$query1 = "SELECT id,username,email FROM users WHERE companyname = '$comName' ORDER BY username";
		$result1 = mysql_query($query1) or die("Query failed : " . mysql_error());
		while ($myrow1 = mysql_fetch_row($result1)) {
			printf("<li><a  href=\"main.php?userID=%s\" target=\"main\">%s</a></li>",$myrow1[0],$myrow1[1]);
		}
		printf("</ul>");
		printf("</li>");
	}
	$count = $count + 1;
}

/* Free resultset */
mysql_free_result($result);

/* Closing connection */
mysql_close($link);
?>
  </ul>
</div>
</body>
</html>
