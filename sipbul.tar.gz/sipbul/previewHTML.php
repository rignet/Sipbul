<html>
<head>
<link rel="STYLESHEET" type="text/css" href=".styles.css">

<script language="JavaScript">
<!--

alert(opener.document.frmMail.fromemail.value);

//function Preview(form)
//	{
	var from = opener.document.frmMail.fromemail.value;
	var to = opener.document.frmMail.to.value;
	var cc = opener.document.frmMail.cc.value;
	var bcc = opener.document.frmMail.bcc.value;
	var mailtext = opener.document.frmMail.mailtext.value;
	//pop = window.open('','popup', 'scrollbars = yes, toolbar = no, status = no');
	//setup1 = 'toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=no,copyhistory=no,width=600,height=550';
	//var pop = window.open ('','Preview',setup1);
	//document.open();
	//document.writeln('<head>');
	document.writeln('<Title>');
	document.writeln('Preview');
	document.writeln('</Title>');
	//document.writeln('<link rel=\"STYLESHEET\" type=\"text/css\" href=\"styles.css\">');
	document.writeln('</head>');
	document.writeln('<body>');
	document.writeln('<center>');
	document.writeln('<h2>Preview</h2><br>');
	document.writeln('</center>');
	document.writeln('<form method=post action=\"\" name=\"frmMail\" id=\"frmMail\">');
	document.writeln('<table>');
	document.writeln('<tr>');
	document.writeln('<td colspan=\"2\"><b>From:&nbsp;&nbsp;</b></td> <td colspan=\"2\">' + document.frmMail.fromemail.value + '</td>');
	//document.writeln('<br>');
	document.writeln('</tr>');
	document.writeln('<tr>');
	document.writeln('<td colspan=\"2\"><b>To:&nbsp;&nbsp;</b></td> <td colspan=\"2\"> ' + to + '</td>');
	//document.writeln('<br>');
	document.writeln('</tr>');
	document.writeln('<tr>');
	document.writeln('<td colspan=\"2\"><b>CC:&nbsp;&nbsp;</b></td> <td colspan=\"2\"> ' + cc + '</td>');
	//document.writeln('<br>');
	document.writeln('</tr>');
	document.writeln('<tr>');
	document.writeln('<td colspan=\"2\"><b>BCC:&nbsp;&nbsp;</b></td> <td colspan=\"2\"> ' + bcc + '</td>');
	//document.writeln('<br>');
	document.writeln('</tr>');
	document.writeln('<tr>');
	document.writeln('<td colspan=\"2\"><b>Message:&nbsp;&nbsp;</b></td> <td colspan=\"2\"> ' + mailtext + '</td>');
	//document.writeln('<br>');
	document.writeln('</tr>');
	document.writeln('</table>');
	document.writeln('</form>');
	document.writeln('<br><p><center><a href="javascript:window.close();">Close Window</a></p>');
	//document.writeln('</body>');
	//document.close();
//}

//-->
</script>

</head>
<body>



</body>
</html>