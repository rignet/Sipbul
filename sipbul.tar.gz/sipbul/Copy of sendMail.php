<html>

<link rel="STYLESHEET" type="text/css" href="styles.css">

<head>
<script language="Javascript">
<!--
if (document.images) {
//on buttons
	imgBoldon = new Image();
	imgBoldon.src = "/stratos/images/bold_on.gif";
	imgItalicon = new Image();
	imgItalicon.src = "/stratos/images/italic_on.gif";
	imgUnderlineon = new Image();
	imgUnderlineon.src = "/stratos/images/underline_on.gif";
	imgOrderedListon = new Image();
	imgOrderedListon.src = "/stratos/images/orderedlist_on.gif";
	imgUnorderedListon = new Image();
	imgUnorderedListon.src = "/stratos/images/unorderedlist_on.gif";
	imgAlignLefton = new Image();
	imgAlignLefton.src = "/stratos/images/alignleft_on.gif";
	imgAlignCenteron = new Image();
	imgAlignCenteron.src = "/stratos/images/aligncenter_on.gif";
	imgAlignRighton = new Image();
	imgAlignRighton.src = "/stratos/images/alignright_on.gif";
	imgInsertLinkon = new Image();
	imgInsertLinkon.src = "/stratos/images/insertlink_on.gif";
	imgClearHtmlon = new Image();
	imgClearHtmlon.src = "/stratos/images/clearhtml_on.gif";

//off buttons
	imgBoldoff = new Image();
	imgBoldoff.src = "/stratos/images/bold_off.gif";
	imgItalicoff = new Image();
	imgItalicoff.src = "/stratos/images/italic_off.gif";
	imgUnderlineoff = new Image();
	imgUnderlineoff.src = "/stratos/images/underline_off.gif";
	imgOrderedListoff = new Image();
	imgOrderedListoff.src = "/stratos/images/orderedlist_off.gif";
	imgUnorderedListoff = new Image();
	imgUnorderedListoff.src = "/stratos/images/unorderedlist_off.gif";
	imgAlignLeftoff = new Image();
	imgAlignLeftoff.src = "/stratos/images/alignleft_off.gif";
	imgAlignCenteroff = new Image();
	imgAlignCenteroff.src = "/stratos/images/aligncenter_off.gif";
	imgAlignRightoff = new Image();
	imgAlignRightoff.src = "/stratos/images/alignright_off.gif";
	imgInsertLinkoff = new Image();
	imgInsertLinkoff.src = "/stratos/images/insertlink_off.gif";
	imgClearHtmloff = new Image();
	imgClearHtmloff.src = "/stratos/images/clearhtml_off.gif";
}

function changeImages() {
	if (document.images) {
		for (var i=0; i<changeImages.arguments.length; i+=2) {
			document[changeImages.arguments[i]].src = eval(changeImages.arguments[i+1] + ".src");
		}
	}
}

function StoreCaret (textEl) {
	var optionObject;
	optionObject = eval(textEl);

	if (optionObject.createTextRange) {
		optionObject.caretPos = document.selection.createRange().duplicate();
	}
}

function InsertAddLink (textEl,strType) {
	var url = prompt('Enter the URL location :','http:\/\/')
	var optionObject;
	optionObject = eval(textEl);
	if (url != null) {
		var strResultText = "";
		strResultText = (document.all) ? document.selection.createRange().text :
		document.frmContentTemplateStoryEditor.text.value = strResultText ;
		document.selection.createRange().text = "";
		var caretPos = optionObject.caretPos;
		caretPos.text = caretPos.text.charAt(caretPos.text.length) == ' ' ? strOpen + ' ':
		'<a href=\"' + url + '\">' + strResultText + '</a>';
	}
	window.status=strType;
}

function InsertAtCursor (textEl,strOpen,strClose,strType) {
	var strResultText = "";
	var optionObject;
	optionObject = eval(textEl);
	strResultText = (document.all) ? document.selection.createRange().text :
	document.frmContentTemplateStoryEditor.text.value = strResultText ;
	document.selection.createRange().text = "";
	if (optionObject.createTextRange && optionObject.caretPos) {
		var caretPos = optionObject.caretPos;
		caretPos.text = caretPos.text.charAt(caretPos.text.length) == ' ' ? strOpen + ' ':
		strOpen + strResultText + strClose;
	}
	window.status=strType;
}

function InsertLists(textEl,strOpen,strClose,strDivider,strType) {
	var strResultText = "";
	var optionObject;
	optionObject = eval(textEl);
	strResultText = (document.all) ? document.selection.createRange().text :
	document.frmContentTemplateStoryEditor.text.value = strResultText ;
	var strOutPut = "";
	document.selection.createRange().text = "";
	if (optionObject.createTextRange && optionObject.caretPos) {
		for (var i = 0; i < strResultText.length; i++) {
			if ((strResultText.charCodeAt(i) == 13) && (strResultText.charCodeAt(i + 1) == 10)) {
				i++;
				strOutPut += "\r\n" + strDivider;
			}
			else {
				strOutPut += strResultText.charAt(i);
			}
		}
		var caretPos = optionObject.caretPos;
		caretPos.text = caretPos.text.charAt(caretPos.text.length) == ' ' ? strOpen + ' ':
		strOpen + strDivider + strOutPut + strClose + "\r\n";
	}
	window.status=strType;
}

function ClearTags(textEl,strType) {
	var optionObject;
	optionObject = eval(textEl);
	if (!confirm("Are you sure you want to delete the HTML in the " + strType + "?")) {
		optionObject = optionObject.value.replace(/<[^>]*>/g,'');
	//	document.frmContentTemplateStoryEditor.strContentTemplateHeader.value = textEl.replace(/<[^>]*>/g,'');
	}
}

function ConvertBR(input) {
// Converts carriage returns
// to <BR> for display in HTML
	var output = "";
	for (var i = 0; i < input.length; i++) {
		if ((input.charCodeAt(i) == 13) && (input.charCodeAt(i + 1) == 10)) {
			i++;
			output += "<BR>";
		}
		else {
			output += input.charAt(i);
		}
	}
	return output;
}

function replaceChars(strFind,strReplace,strHTML) {
	temp = '' + strHTML; // temporary holder

	while (temp.indexOf(strFind)>-1) {
		pos= temp.indexOf(strFind);
		temp = '' + (temp.substring(0, pos) + strReplace + temp.substring((pos + strFind.length), temp.length));
	}
	return temp;
}


function Preview(form)
	{
	var from = form.fromemail.value;
	var to = form.to.value;
	var cc = form.cc.value;
	var bcc = form.bcc.value;
	var mailtext = form.mailtext.value;
	setup1 = 'toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=no,copyhistory=no,width=600,height=550';
	pop = window.open ("","pop",setup1);
	pop.location.reload();
	pop.document.write('<head>');
	pop.document.write('<Title>');
	pop.document.write('Preview');
	pop.document.write('</Title>');
	pop.document.write('<link rel=\"STYLESHEET\" type=\"text/css\" href=\"styles.css\">');
	pop.document.write('</head>');
	pop.document.write('<body>');
	pop.document.write('<center>');
	pop.document.write('<h2>Preview</h2><br>');
	pop.document.write('</center>');
	pop.document.write('<form method=post action=\"\" name=\"frmMail\" id=\"frmMail\">');
	pop.document.write('<table>');
	pop.document.write('<tr>');
	pop.document.write('<td colspan=\"2\"><b>From:&nbsp;&nbsp;</b></td> <td colspan=\"2\">' + from + '</td>');
	//pop.document.write('<br>');
	pop.document.write('</tr>');
	pop.document.write('<tr>');
	pop.document.write('<td colspan=\"2\"><b>To:&nbsp;&nbsp;</b></td> <td colspan=\"2\"> ' + to + '</td>');
	//pop.document.write('<br>');
	pop.document.write('</tr>');
	pop.document.write('<tr>');
	pop.document.write('<td colspan=\"2\"><b>CC:&nbsp;&nbsp;</b></td> <td colspan=\"2\"> ' + cc + '</td>');
	//pop.document.write('<br>');
	pop.document.write('</tr>');
	pop.document.write('<tr>');
	pop.document.write('<td colspan=\"2\"><b>BCC:&nbsp;&nbsp;</b></td> <td colspan=\"2\"> ' + bcc + '</td>');
	//pop.document.write('<br>');
	pop.document.write('</tr>');
	pop.document.write('<tr>');
	pop.document.write('<td colspan=\"2\"><b>Message:&nbsp;&nbsp;</b></td> <td colspan=\"2\"> ' + mailtext + '</td>');
	//pop.document.write('<br>');
	pop.document.write('</tr>');
	pop.document.write('</table>');
	pop.document.write('</form>');
	pop.document.write('<br><p><center><a href="javascript:window.close();">Close Window</a></p>');
	pop.document.write('</body>');

}

function AddUser()
	{
	//var from = document.frmMail.from.value
	//var to = document.frmMail.to.value
	//var mailtext = document.frmMail.mailtext.value
	setup2 = 'toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=no,copyhistory=no,width=600,height=550';
	pop = window.open ("addUser.php","pop",setup2);

}


//-->
</script>

<script language="JavaScript" src="/jspellhtml/jspellpopup.js"></script>
<script language="JavaScript">
<!--
var spellCheckURL="/jspellhtml/JSpell"; // change to point to the JSpell Spell Check Server
var imagePath="/jspellhtml/images"; // relative URL to JSpell button images directory

function getSpellCheckItem(jspell_n) {
   var fieldsToCheck=getSpellCheckArray();
   return fieldsToCheck[jspell_n];
}
//-->
</script>
</head>
<body>

<form method=post action="processing/processMail.php" name="frmMail" id="frmMail">
 <table>
   <tr>
     <td colspan="2">From:  </td>
     <td colspan="2"> <select name="fromemail"><option value="">Select From Email</option>
<?php
include ("dbconfig.php");
$link = mysql_connect($host,$usr,$pwd)
or die("Could not connect : " . mysql_error());

//echo "Connected successfully";
mysql_select_db($db) or die("Could not select database");

/* Performing SQL query */
$query = "SELECT adminname,email FROM admin ORDER BY adminname";
$result = mysql_query($query) or die("Query failed : " . mysql_error());
$adminnames ='';
/* Printing results in HTML */
while ($myrow = mysql_fetch_row($result)) {
	if ($adminnames == '') {
		$adminnames = $myrow[0];
		printf("<option value=\"%s\">%s</option>\n",$myrow[1], $myrow[0]);
		//echo $adminnames;
	}
	else {

		$adminnames = $adminnames."; ".$myrow[0];
		printf("<option value=\"%s\">%s</option>\n",$myrow[1], $myrow[0]);
		//$adminnames = $adminnames.$adminname;
		//echo $adminnames;
	}
}
//$adminnames = str_replace(";", " ",$adminnames);

/* Free resultset */
mysql_free_result($result);

/* Closing connection */
mysql_close($link);
?>
     </select></td>
     <input type="hidden" name="from" value="kiranpaturi@gmail.com">
   </tr>
   <tr>
     <td colspan="2">To:  </td>
     <td colspan="2"> <textarea name="to" cols="45" rows="2"></textarea><input type="button" name="Add User" value="Add User" onClick="AddUser();" tabindex="8" /> </td>
   </tr>
   <tr>
        <td colspan="2"><label for="cc">CC:  </label></td>
        <td colspan="2"> <textarea name="cc" cols="45" rows="2"></textarea> </td>
   </tr>
   <tr>
        <td colspan="2"><label for="bcc">BCC:  </label></td>
        <td colspan="2"> <textarea name="bcc" cols="45" rows="2"><?php echo $adminnames ?></textarea> </td>
   </tr>
   <tr>
     <td colspan="2"><label for="message">Message:  </label></td>
     <td colspan="2"> <textarea name="mailtext" cols="45" rows="10" OnSelect="StoreCaret(this);" OnClick="StoreCaret(this);" OnKeyUp="StoreCaret(this);" OnDBLClick="StoreCaret(this);"></textarea>
	 <br><A HREF="#" onMouseOver="changeImages('imgBold', 'imgBoldon');window.status='Bold';return true;" onMouseOut="window.status='';changeImages('imgBold', 'imgBoldoff')" OnClick="InsertAtCursor(document.frmMail.mailtext,'<b>','</b>','Bold');return false;"><img src="/stratos/images/bold_off.gif" NAME="imgBold" WIDTH=25 HEIGHT=25 BORDER="0" ALT="Bold"><A HREF="#" onMouseOver="changeImages('imgItalic', 'imgItalicon');window.status='Italic';return true;" onMouseOut="window.status='';changeImages('imgItalic', 'imgItalicoff')" OnClick="InsertAtCursor(document.frmMail.mailtext,'<i>','</i>','Italic');return false;"><img src="/stratos/images/italic_off.gif" NAME="imgItalic" WIDTH=25 HEIGHT=25 BORDER="0" ALT="Italic"><A HREF="#" onMouseOver="changeImages('imgUnderline', 'imgUnderlineon');window.status='Underline';return true;" onMouseOut="window.status='';changeImages('imgUnderline', 'imgUnderlineoff')" OnClick="InsertAtCursor(document.frmMail.mailtext,'<u>','</u>','Underline');return false;"><img src="/stratos/images/underline_off.gif" NAME="imgUnderline" WIDTH=27 HEIGHT=25 BORDER="0" ALT="Underline"><A HREF="#" onMouseOver="changeImages('imgOrderedList', 'imgOrderedListon');window.status='Ordered List';return true;" onMouseOut="window.status='';changeImages('imgOrderedList', 'imgOrderedListoff')" OnClick="InsertLists(document.frmMail.mailtext,'<ol>','</ol>','<li>','Ordered List');return false;"><img src="/stratos/images/orderedlist_off.gif" NAME="imgOrderedList" WIDTH=27 HEIGHT=25 BORDER="0" ALT="Ordered List"><A HREF="#" onMouseOver="changeImages('imgUnorderedList', 'imgUnorderedListon');window.status='Unordered List';return true;" onMouseOut="window.status='';changeImages('imgUnorderedList', 'imgUnorderedListoff')" OnClick="InsertLists(document.frmMail.mailtext,'<ul>','</ul>','<li>','Unordered List');return false;"><img src="/stratos/images/unorderedlist_off.gif" NAME="imgUnorderedList" WIDTH=25 HEIGHT=25 BORDER="0" ALT="Unordered List"><A HREF="#" onMouseOver="changeImages('imgAlignLeft', 'imgAlignLefton');window.status='Align Left';return true;" onMouseOut="window.status='';changeImages('imgAlignLeft', 'imgAlignLeftoff')" OnClick="InsertAtCursor(document.frmMail.mailtext,'<div align=left>','</div>','Align Left');return false;"><img src="/stratos/images/alignleft_off.gif" NAME="imgAlignLeft" WIDTH=27 HEIGHT=25 BORDER="0" ALT="Align Left"><A HREF="#" onMouseOver="changeImages('imgAlignCenter', 'imgAlignCenteron');window.status='Align Center';return true;" onMouseOut="window.status='';changeImages('imgAlignCenter', 'imgAlignCenteroff')" OnClick="InsertAtCursor(document.frmMail.mailtext,'<center>','</center>','Align Center');return false;"><img src="/stratos/images/aligncenter_off.gif" NAME="imgAlignCenter" WIDTH=25 HEIGHT=25 BORDER="0" ALT="Align Center"><A HREF="#" onMouseOver="changeImages('imgAlignRight', 'imgAlignRighton');window.status='Align Right';return true;" onMouseOut="window.status='';changeImages('imgAlignRight', 'imgAlignRightoff')" OnClick="InsertAtCursor(document.frmMail.mailtext,'<div align=right>','</div>','Align Right');return false;" ><img src="/stratos/images/alignright_off.gif" NAME="imgAlignRight" WIDTH=25 HEIGHT=25 BORDER="0" ALT="Align Right"></td>
   </tr>
   <tr>
     <td colspan="4"><center><input type="submit" name="Submit" value="Send" tabindex="8" />&nbsp;&nbsp;<input type="reset" value="Preview" onClick="Preview(this.form);">&nbsp;&nbsp;<input type="reset" value="Reset"></center></td>
   </tr>
 </table>
</form>

</body>
</html>