<html>
<head>
<link rel="STYLESHEET" type="text/css" href="tree.css">
<link rel="STYLESHEET" type="text/css" href="styles.css">


<script language="JavaScript">
<!--

	function ProcessForm(){
		var testresults;
		var strSubmitMessage = '';
		var blnStopSubmission = false;

		//Validate Company Name
		if (isEmpty(document.frmMail.comname1.value) && isEmpty(document.frmMail.comname2.value)) {
			blnStopSubmission = true;
			strSubmitMessage = strSubmitMessage + '\      Please Select/Enter Company Name\n';
		}
		//Validate User Name
		if (isEmpty(document.frmMail.name.value)) {
			blnStopSubmission = true;
			strSubmitMessage = strSubmitMessage + '\      Please Enter User Name\n';
		}

		// the following expression must be all on one line...
		var goodEmail = document.frmMail.email.value.match(/\b(^(\S+@).+((\.com)|(\.net)|(\.edu)|(\.mil)|(\.gov)|(\.org)|(\..{2,2}))$)\b/gi);
		if (goodEmail){
		   //good = true
		} else {
		 //  alert('Please enter a valid e-mail address.')
		   blnStopSubmission = true;
		   strSubmitMessage = strSubmitMessage + '\      Please enter a valid e-mail address\n';
   }

		//Submit the form
		if(!blnStopSubmission) {
			if (isEmpty(document.frmMail.comname2.value)) {
				document.frmMail.comname.value = document.frmMail.comname1.value
			}
			else {
				document.frmMail.comname.value = document.frmMail.comname2.value
			}
			//alert(document.frmMail.comname.value);
			document.frmMail.submit();
		}
		else {
			alert(strSubmitMessage);
		}
	}

	//Check whether string s is empty.
	function isEmpty(s) {
		return ((s == null) || (s.length == 0))
	}




//-->
</script>

</head>
<body>
<div id="p7swapmenu">
<form method=post action="processing/processAddUser.php" name="frmMail" id="frmMail">
<input type="hidden" name="comname" value="">
 <table>
 	<tr>
	 <td colspan="2">Company Name:  </td>
	 <td colspan="2"> <select name="comname1"><option value="">Select Company Name</option>
<?php
include ("dbconfig.php");
$link = mysql_connect($host,$usr,$pwd)
or die("Could not connect : " . mysql_error());

//echo "Connected successfully";
mysql_select_db($db) or die("Could not select database");

/* Performing SQL query */
$query = "SELECT DISTINCT companyname FROM users ORDER BY companyname";
$result = mysql_query($query) or die("Query failed : " . mysql_error());

/* Printing results in HTML */
while ($myrow = mysql_fetch_row($result)) {
	printf("<option value=\"%s\">%s</option>\n",$myrow[0], $myrow[0]);
}

/* Free resultset */
mysql_free_result($result);

/* Closing connection */
mysql_close($link);
?>
     </select> Or <input type="text" name="comname2" size=25></td>
   </tr>
   <tr>
     <td colspan="2">User Name:  </td>
     <td colspan="2"> <input type="text" name="name" size=30></td>
   </tr>
   <tr>
     <td colspan="2">User Email:  </td>
     <td colspan="2"> <input type="text" name="email" size=30> </td>
   </tr>
   <tr>
        <td colspan="2">SIP Login:  </td>
        <td colspan="2"> <input type="text" name="loginname" size=20> </td>
   </tr>

   <tr>
        <td colspan="2">Interest Level:  </td>
        <td colspan="2"><input type="radio" name="interest" value="Critical"><img src="images/icon_critical.gif" width="16" height="16" border="0" alt="Critical">&nbsp;Critical<br><input type="radio" name="interest" value="Major"><img src="images/icon_major.gif" width="16" height="16" border="0" alt="Major">&nbsp;Major<br><input type="radio" name="interest" value="Minor"><img src="images/icon_minor.gif" width="16" height="16" border="0" alt="Minor">&nbsp;Minor<br><input type="radio" name="interest" value="Warning"><img src="images/icon_warning.gif" width="16" height="16" border="0" alt="Warning">&nbsp;Warning<br><input type="radio" name="interest" value="Normal"><img src="images/icon_normal.gif" width="16" height="16" border="0" alt="Normal">&nbsp;Normal<br><input type="radio" name="interest" value="Informational" checked><img src="images/icon_unknown.gif" width="16" height="16" border="0" alt="Unknown">&nbsp;Informational</td>

   </tr>
<!--
   <tr>
        <td colspan="2">Password:  </td>
        <td colspan="2"> <input type="password" name="loginpass" size=20> (Six characters or more, may consist  a-z and 0-9)</td>
   </tr>
-->
   <tr>
        <td colspan="4"><center><input type="button" name="Submit" value="Submit" OnClick="ProcessForm();" tabindex="8" />&nbsp;&nbsp;<input type="reset" value="Reset"></center></td>
   </tr>
</table>
<p><p>
<table>
   <tr align=\"top\">
<?php
include ("dbconfig.php");
$link = mysql_connect($host,$usr,$pwd)
or die("Could not connect : " . mysql_error());

//echo "Connected successfully";
mysql_select_db($db) or die("Could not select database");

/* Performing SQL query */
$query = "SELECT DISTINCT companyname FROM users ORDER BY companyname";
$result = mysql_query($query) or die("Query failed : " . mysql_error());

/* Printing results in HTML */
printf("<td colspan=\"2\"><label for=\"name\"><b>Company Name</b></label></td>");
printf("<td colspan=\"2\"><label for=\"name\"><b>Action</b></label></td></tr>");
//printf("<tr><td colspan=\"2\" align=\"top\">");
while ($myrow = mysql_fetch_row($result)) {

	printf("<tr><td colspan=\"2\"><label for=\"name\">%s</label></td><td colspan=\"2\"><label for=\"name\"><a href=\"processing/processAddUser.php?delete=%s\" onClick=\"return confirm('Are you sure you want to delete?');\" >delete</a></label></td></tr>", $myrow[0],$myrow[0]);
}

/* Free resultset */
mysql_free_result($result);

/* Closing connection */
mysql_close($link);
?>

   </tr>
</table>

<p><p>
<table>
   <tr align=\"top\">
<?php
include ("dbconfig.php");
$link = mysql_connect($host,$usr,$pwd)
or die("Could not connect : " . mysql_error());

//echo "Connected successfully";
mysql_select_db($db) or die("Could not select database");

/* Performing SQL query */
$query = "SELECT DISTINCT id,companyname,username,email,loginName FROM users ORDER BY companyname,username";
$result = mysql_query($query) or die("Query failed : " . mysql_error());

/* Printing results in HTML */
printf("<td colspan=\"2\"><label for=\"name\"><b>Company Name</b></label></td>");
printf("<td colspan=\"2\"><label for=\"name\"><b>User Name</b></label></td>");
printf("<td colspan=\"2\"><label for=\"name\"><b>Email</b></label></td>");
printf("<td colspan=\"2\"><label for=\"name\"><b>SIP Login</b></label></td>");
printf("<td colspan=\"2\"><label for=\"name\"><b>Action</b></label></td></tr>");
//printf("<tr><td colspan=\"2\" align=\"top\">");
while ($myrow = mysql_fetch_row($result)) {

	printf("<tr><td colspan=\"2\"><label for=\"name\">%s</label></td><td colspan=\"2\"><label for=\"name\">%s</label></td><td colspan=\"2\"><label for=\"name\">%s</label><td colspan=\"2\"><label for=\"name\">%s</label></td><td colspan=\"2\"><label for=\"name\"><a href=\"processing/processAddUser.php?id=%s\" onClick=\"return confirm('Are you sure you want to delete?');\" >delete</a></label> | <a href=\"userUpdate.php?id=%s\">update</a></td></tr>", $myrow[1],$myrow[2],$myrow[3],$myrow[4],$myrow[0],$myrow[0]);
}

/* Free resultset */
mysql_free_result($result);

/* Closing connection */
mysql_close($link);
?>

   </tr>
</table>

</form>
</div>
</body>
</html>
