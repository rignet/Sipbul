<html>
<head>

<link rel="STYLESHEET" type="text/css" href="styles.css">
<link rel="STYLESHEET" type="text/css" href="tree.css">


</head>
<body>

<form method=post action="viewEmail.php" name="frmMail" id="frmMail">
<div id="p7swapmenu">
<table>
   <tr align=\"top\">
<?php
include ("dbconfig.php");
$link = mysql_connect($host,$usr,$pwd)
or die("Could not connect : " . mysql_error());

//echo "Connected successfully";
mysql_select_db($db) or die("Could not select database");

if (!$_GET['emailID'] == '') {
$emailID = $_GET['emailID'];
}

$userID = $_GET['userid'];


/* Performing SQL query */
$query = "SELECT email.id, email.subject,email.body,email.admin,email.date,email.emailtype,email.service,email.region,email.startdate,email.starttime,email.endtime,email.duration,email.reason,email.updatetext,email.starttimezone,email.endtimezone,email.unknownend FROM email WHERE id = '$emailID' ORDER BY date DESC";
$result = mysql_query($query) or die("Query failed : " . mysql_error());

//echo $emailID." = emailid<br>";
//echo $userID." = userid<br>";
//echo $query."= query <br>";

/* Printing results in HTML */
while ($myrow = mysql_fetch_row($result)) {
//$userID = $myrow[1];
$subject = $myrow[1];
$emailbody = $myrow[2];
$emailtype = $myrow[5];
$emaildate = $myrow[4];
$service = $myrow[6];
$region = $myrow[7];
$startdate = $myrow[8];
$starttime = $myrow[9];
$endtime = $myrow[10];
$duration = $myrow[11];
$reason = $myrow[12];
$updatetext = $myrow[13];
$starttimezone = $myrow[14];
$endtimezone = $myrow[15];
$unknownend= $myrow[16];
$service = '<b>Please be advised of an interruption to the following Stratos service(s):</b> '.$service;
$region = '<br><br><b>Region(s) Affected: </b>'.$region;
$startdate = '<br><br><b>Interruption Window Start Date and Time:</b> '.date("l F d Y H:i:s",strtotime($startdate)).' '.$starttimezone;
$starttime = '<br><br><b>Interruption Window Start Time:</b> '.date("l F d Y H:i:s",strtotime($starttime));

if ( $unknownend == 0 ) {
	$endtime = '<br><br><b>Interruption Window End Date and Time:</b> '.date("l F d Y H:i:s",strtotime($endtime)).' '.$endtimezone;
	$appduration = '<br><br><b>Approximate Duration:</b> '.$duration;
}
else {
	$endtime = '<br><br><b>Interruption Window End Date and Time:</b> Unknown';
	$appduration = '<br><br><b>Approximate Duration:</b> Unknown';
}

//$endtime = '<br><br><b>Interruption Window End Date and Time:</b> '.date("l F d Y H:i:s",strtotime($endtime)).' '.$endtimezone;
//$appduration = '<br><br><b>Approximate Duration:</b> '.$duration;
//$reason = $_POST['mailtext1'];
$mailtext1 = '<br><br><b>Reason:</b> '.$reason;
$mailtext2 = $_POST['mailtext2'];

$severity = '<br><br><b>Severity: </b>'.$emailtype;

$emailbody = $service.$severity.$region.$startdate.$endtime.$appduration.$mailtext1.'<br><br><font size="1" color="blue">'.$updatetext.'</font><br>';
}



if (strcasecmp($userID, 'admin') == 0) {
	$userID = $HTTP_COOKIE_VARS["cookid"];
	$query2 = "SELECT DISTINCT adminname,email FROM admin WHERE id = '$userID'";
	$result2 = mysql_query($query2) or die("Query failed : " . mysql_error());
	while ($myrow = mysql_fetch_row($result2)) {
		$userName = $myrow[0];
		$userEmail = $myrow[1];
	}
	mysql_free_result($result2);
}

else {

	$query2 = "SELECT DISTINCT username,email FROM users WHERE id = '$userID'";
	$result2 = mysql_query($query2) or die("Query failed : " . mysql_error());
	while ($myrow = mysql_fetch_row($result2)) {
		$userName = $myrow[0];
		$userEmail = $myrow[1];
	}
	mysql_free_result($result2);
}

if (!$emailID == '') {

$query = "UPDATE useremails SET useremails.status = 'old' WHERE useremails.emailid = '$emailID'";

mysql_query($query);

}

$query = "SELECT DISTINCT disclaimer FROM disclaimer";
$result = mysql_query($query) or die("Query failed : " . mysql_error());

/* Printing results in HTML */
while ($myrow = mysql_fetch_row($result)) {
	$disclaimer = $myrow[0];
	$emailbody = $emailbody.'<br>'.$disclaimer;
}

/* Free resultset */
mysql_free_result($result);


/* Closing connection */
mysql_close($link);
?>


<td colspan="2"><b>From:&nbsp;&nbsp;</b></td><td colspan="2">Stratos Admin < networkops@stratosglobal.com > </td>

</tr>
<tr>
<!--
<td colspan="2"><b>To:&nbsp;&nbsp;</b></td> <td colspan="2"><? echo $userName.' < '.$userEmail.' > '; ?></td>
-->
<td colspan="2"><b>To:&nbsp;&nbsp;</b></td> <td colspan="2"><? echo StratosCustomer; ?></td>

</tr>
<tr>
<td colspan="2"><b>Subject:&nbsp;&nbsp;</b></td> <td colspan="2"><? echo $subject; ?></td>

</tr>
<tr>
<td colspan="2"><b>Message:&nbsp;&nbsp;</b></td> <td colspan="2"><? echo $emailbody; ?></td>

</tr>
</table>
<center><a href="javascript:window.close();">Close Window</a></center>
</form>
</div>

</body>

</html>
