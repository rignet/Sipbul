<html>
<head>
<link rel="STYLESHEET" type="text/css" href="tree.css">
<link rel="STYLESHEET" type="text/css" href="styles.css">


<script language="JavaScript">
<!--

function AddUser()
	{
	//var from = document.frmMail.from.value
	//var to = document.frmMail.to.value
	//var mailtext = document.frmMail.mailtext.value
	setup2 = 'toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=no,copyhistory=no,width=670,height=550';
	pop = window.open ("addUser.php","pop",setup2);

}
	function ProcessForm(){
		var testresults;
		var strSubmitMessage = '';
		var blnStopSubmission = false;

		//Validate Launch Date
		if (isEmpty(document.frmMail.groupname1.value)) {
			blnStopSubmission = true;
			strSubmitMessage = strSubmitMessage + '\      Please Select RigNet Service\n';
		}
		//Validate Launch Date
		if (isEmpty(document.frmMail.to.value)) {
			blnStopSubmission = true;
			strSubmitMessage = strSubmitMessage + '\      Please Enter Users\n';
		}



		//Submit the form
		if(!blnStopSubmission) {
			//if (isEmpty(document.frmMail.groupname2.value)) {
				document.frmMail.groupname.value = document.frmMail.groupname1.value
			//}
			//else {
				//document.frmMail.groupname.value = document.frmMail.groupname2.value
			//}
			//alert(document.frmMail.groupname.value);
			document.frmMail.submit();
		}
		else {
			alert(strSubmitMessage);
		}
	}

	//Check whether string s is empty.
	function isEmpty(s) {
		return ((s == null) || (s.length == 0))
	}




//-->
</script>

</head>
<body>
<div id="p7swapmenu">
<form method=post action="processing/processAddGroup.php" name="frmMail" id="frmMail">
<input type="hidden" name="groupname" value="">
 <table>
 	<tr>
	 <td colspan="2">RigNet Services:  </td>
	 <td colspan="2"> <select name="groupname1"><option value="">Select RigNet Service</option>
<?php
include ("dbconfig.php");
$link = mysql_connect($host,$usr,$pwd)
or die("Could not connect : " . mysql_error());

//echo "Connected successfully";
mysql_select_db($db) or die("Could not select database");

/* Performing SQL query */
$query = "SELECT service,adminid FROM stratosservices ORDER BY service";
$result = mysql_query($query) or die("Query failed : " . mysql_error());

/* Printing results in HTML */
while ($myrow = mysql_fetch_row($result)) {
	printf("<option value=\"%s\">%s</option>\n",$myrow[0], $myrow[0]);
}

/* Free resultset */
mysql_free_result($result);

/* Closing connection */
mysql_close($link);
?>
     </select></td>
   </tr>
   <tr>
        <td colspan="2">Add Users:  </td>
        <td colspan="2"> <textarea name="to" cols="45" rows="2"></textarea><input type="button" name="Add User" value="Add User" onClick="AddUser();" tabindex="8" /> </td>
   </tr
   <tr>
        <td colspan="4"><center><input type="button" name="Submit" value="Submit" OnClick="ProcessForm();" tabindex="8" />&nbsp;&nbsp;<input type="reset" value="Reset"></center></td>
   </tr>
</table>
<p><p>
<table>
   <tr align=\"top\">
<?php
include ("dbconfig.php");
$link = mysql_connect($host,$usr,$pwd)
or die("Could not connect : " . mysql_error());

//echo "Connected successfully";
mysql_select_db($db) or die("Could not select database");

/* Performing SQL query */
$query = "SELECT DISTINCT groupname FROM groups ORDER BY groupname";
$result = mysql_query($query) or die("Query failed : " . mysql_error());

/* Printing results in HTML */
printf("<td colspan=\"2\"><label for=\"name\"><b>RigNet Services</b></label></td>");
printf("<td colspan=\"2\"><label for=\"name\"><b>Action</b></label></td></tr>");
//printf("<tr><td colspan=\"2\" align=\"top\">");
while ($myrow = mysql_fetch_row($result)) {

	printf("<tr><td colspan=\"2\"><label for=\"name\">%s</label></td><td colspan=\"2\"><label for=\"name\"><a href=\"processing/processAddGroup.php?delete=%s\" onClick=\"return confirm('Are you sure you want to delete?');\" >delete</a></label></td></tr>", $myrow[0],$myrow[0]);
}

/* Free resultset */
mysql_free_result($result);

/* Closing connection */
mysql_close($link);
?>

   </tr>
</table>

<p><p>
<table>
   <tr align=\"top\">
<?php
include ("dbconfig.php");
$link = mysql_connect($host,$usr,$pwd)
or die("Could not connect : " . mysql_error());

//echo "Connected successfully";
mysql_select_db($db) or die("Could not select database");

/* Performing SQL query */
$query = "SELECT DISTINCT id,groupname,username,email FROM groups ORDER BY groupname, username";
$result = mysql_query($query) or die("Query failed : " . mysql_error());

/* Printing results in HTML */
printf("<td colspan=\"2\"><label for=\"name\"><b>RigNet Services</b></label></td>");
printf("<td colspan=\"2\"><label for=\"name\"><b>User Name</b></label></td>");
printf("<td colspan=\"2\"><label for=\"name\"><b>Email</b></label></td>");
printf("<td colspan=\"2\"><label for=\"name\"><b>Action</b></label></td></tr>");
//printf("<tr><td colspan=\"2\" align=\"top\">");
while ($myrow = mysql_fetch_row($result)) {
	$usernam = $myrow[2];
	if (!$usernam == '') {
		printf("<tr><td colspan=\"2\"><label for=\"name\">%s</label></td><td colspan=\"2\"><label for=\"name\">%s</label></td><td colspan=\"2\"><label for=\"name\">%s</label></td><td colspan=\"2\"><label for=\"name\"><a href=\"processing/processAddGroup.php?id=%s\" onClick=\"return confirm('Are you sure you want to delete?');\" >delete</a></label></td></tr>", $myrow[1],$myrow[2],$myrow[3],$myrow[0]);
	}
}

/* Free resultset */
mysql_free_result($result);

/* Closing connection */
mysql_close($link);
?>

   </tr>
</table>

</form>
</div>
</body>
</html>
