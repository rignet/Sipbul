<html>
<!-- TWO STEPS TO INSTALL HTML <B style="color:black;background-color:#ffff66">PREVIEW</B>:

  1.  Copy the coding into the HEAD of your HTML document
  2.  Add the last code into the BODY of your HTML document  -->

<!-- STEP ONE: Paste this code into the HEAD of your HTML document  -->

<HEAD>

<SCRIPT LANGUAGE="JavaScript">
<!-- Original:  nsabs@1nsyncfan.com -->
<!-- Web Site:  http://www.envy.nu/gjelly -->

<!-- This script and many more are available free online at -->
<!-- The <B style="color:black;background-color:#A0FFFF">JavaScript</B> Source!! http://<B style="color:black;background-color:#A0FFFF">javascript</B>.internet.com -->

<!-- Begin
function displayHTML(form) {
var inf = form.htmlArea.value;
win = window.open("", 'popup', 'toolbar = no, status = no');
win.document.write("" + inf + "");
}
//  End -->
</script>

</HEAD>

<!-- STEP TWO: Copy this code into the BODY of your HTML document  -->

<BODY>

<form>
<textarea name="htmlArea" cols=45 rows=6>
</textarea>
<br>
<input type="button" value=" view " onclick="displayHTML(this.form);">
</form>

<p><center>
<font face="arial, helvetica" size"-2">Free JavaScripts provided<br>
by <a href="http://javascriptsource.com">The <B style="color:black;background-color:#A0FFFF">JavaScript</B> Source</a></font>
</center><p>

</html>