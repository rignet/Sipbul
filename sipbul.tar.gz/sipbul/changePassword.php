<html>
<head>

<link rel="STYLESHEET" type="text/css" href="styles.css">
<link rel="STYLESHEET" type="text/css" href="tree.css">

<script language="JavaScript">
<!--

	function ProcessForm(){
		var testresults;
		var strSubmitMessage = '';
		var blnStopSubmission = false;
		var psw1 = document.frmMail.newone.value;
		var psw2 = document.frmMail.newtwo.value;

		//Validate Launch Date
		if (isEmpty(document.frmMail.old.value)) {
			blnStopSubmission = true;
			strSubmitMessage = strSubmitMessage + '\      Please Enter Old Password\n';
		}

		//Validate Launch Date
		if (psw1 != psw2) {
			blnStopSubmission = true;
			strSubmitMessage = strSubmitMessage + '\      New Passwords does not match\n';
		}




		//Submit the form
		if(!blnStopSubmission) {
			document.frmMail.submit();
		}
		else {
			alert(strSubmitMessage);
		}
	}

	//Check whether string s is empty.
	function isEmpty(s) {
		return ((s == null) || (s.length == 0))
	}




//-->
</script>

</head>
<?php
include ("dbconfig.php");
$link = mysql_connect($host,$usr,$pwd)
or die("Could not connect : " . mysql_error());

//echo "Connected successfully";
mysql_select_db($db) or die("Could not select database");
$nameID = $_GET['nameID'];
if (!$_POST['newone'] == '') {
$password = $_POST['newone'];
}

if (!$_POST['id'] == '') {
$nameID = $_POST['id'];
}

if (!$nameID == '' && !$password == '') {
//echo $nameID.$password;
	/* Performing SQL query */
	$query = "UPDATE admin SET password = '$password' WHERE id = '$nameID'";

	mysql_query($query);
	$strdisplay = 'changed';
	//echo "<font color=red>Password changed!!</font>";
}

/* Closing connection */
mysql_close($link);
?>

<body>
<div id="p7swapmenu">
<form method=post action="changePassword.php" name="frmMail" id="frmMail">
<input type="hidden" name="id" value="<?php echo $nameID ; ?>">
 <table>
   <tr>
     <td colspan="2">Old Password:  </td>
     <td colspan="2"> <input type="password" name="old" size=20></td>
   </tr>
   <tr>
     <td colspan="2">New Password:  </td>
     <td colspan="2"> <input type="password" name="newone" size=20> </td>
   </tr>
   <tr>
        <td colspan="2">Re-enter New Password:  </td>
        <td colspan="2"> <input type="password" name="newtwo" size=20> </td>
   </tr>

   <tr>
        <td colspan="4"><center><input type="button" name="Submit" value="Submit" OnClick="ProcessForm();" tabindex="8" />&nbsp;&nbsp;<input type="reset" value="Reset"></center></td>
   </tr>
   <?php
   		if ($strdisplay == 'changed') {
   			echo "<font color=red>Password changed!!</font>";
   		}
   ?>
</table>


</form>
</div>
</body>
</html>