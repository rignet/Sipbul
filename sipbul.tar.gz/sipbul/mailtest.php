<html>
<head>
<title>Submit Form</title>
</head>



<body>
Thank You,<br>
<br>
Your Trouble Submission Form has been Submitted.

<?php
$msg= " Testing\n";

$recipient = "john.ritter@stratosglobal.com";
//$recipient = "jgjorda@bellsouth.net";
$subject= "PHP Mail Test";
$mailheaders= "From: WebPortal@stratosglobal.com\n";

mail($recipient, $subject, $msg, $mailheaders);
?>
</body>
</html>
