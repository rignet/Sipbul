<html>
<head>

<link rel="STYLESHEET" type="text/css" href="styles.css">
<link rel="STYLESHEET" type="text/css" href="tree.css">

<script language="JavaScript">
<!--

	function ProcessForm(){
		var testresults;
		var strSubmitMessage = '';
		var blnStopSubmission = false;

		//Validate Launch Date
		if (isEmpty(document.frmMail.name.value)) {
			blnStopSubmission = true;
			strSubmitMessage = strSubmitMessage + '\      Please Enter Admin Name\n';
		}

		// the following expression must be all on one line...
		var goodEmail = document.frmMail.email.value.match(/\b(^(\S+@).+((\.com)|(\.net)|(\.edu)|(\.mil)|(\.gov)|(\.org)|(\..{2,2}))$)\b/gi);
		if (goodEmail){
		   //good = true
		}
		else {
		   //alert('Please enter a valid e-mail address.')
		   blnStopSubmission = true;
		   strSubmitMessage = strSubmitMessage + '\      Please enter a valid e-mail address\n';
   		}

		//Submit the form
		if(!blnStopSubmission) {
			document.frmMail.submit();
		}
		else {
			alert(strSubmitMessage);
		}
	}

	//Check whether string s is empty.
	function isEmpty(s) {
		return ((s == null) || (s.length == 0))
	}

function ViewEmail(id,userid)
	{
	//alert(id);
	setup2 = 'toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=no,copyhistory=no,width=680,height=550';
	pop = window.open ("viewEmail.php?emailID="+ id + "&userid="+ userid,"pop",setup2);

}


//-->
</script>

</head>
<body>
<div id="p7swapmenu">
<form method=post action="" name="frmMail" id="frmMail">
<table>
   <tr align=\"top\">
<?php
include ("dbconfig.php");
$link = mysql_connect($host,$usr,$pwd)
or die("Could not connect : " . mysql_error());

//echo "Connected successfully";
mysql_select_db($db) or die("Could not select database");

$UserNam = $HTTP_COOKIE_VARS["cookname"];
$UserEmailid = $HTTP_COOKIE_VARS["cookemail"];
$UserType = 'admin';
//$UserNam = $_SESSION['username'];

//echo date("l F d Y H:i:s",strtotime("2005-03-29 21:16:05")).'<br>';
if (!$_GET['userID'] == '') {
	$UserID = $_GET['userID'];
	echo $UserID.' Mail Box<br><br>';
	/* Performing SQL query */
	//$query = "SELECT id,subject,admin,date FROM email ORDER BY date DESC";
	//$query = "SELECT useremails.id, useremails.status ,email.id, email.subject, email.admin, email.date, email.emailtype, email.emailupdate,email.updateid,useremails.userid,email.service FROM useremails INNER JOIN email ON useremails.emailid = email.id WHERE useremails.userid = '$UserID' AND email.updateid = 'empty' ORDER BY date DESC";

if(isset($_GET['sortby'])){
$sortby = $_GET['sortby'];
if(strcasecmp($sortby, "desc")==0){
$newsort = "ASC";
	}
else{
$newsort = "DESC";
$sortby = "ASC";
    }
}

if(isset($_GET['orderby'])){
$orderby = $_GET['orderby'];
$query_sv.= "SELECT useremails.id, useremails.status ,email.id, email.subject, email.admin, email.date, email.emailtype, email.emailupdate,email.updateid,useremails.userid FROM useremails INNER JOIN email ON useremails.emailid = email.id WHERE useremails.userid = '$UserID' AND email.updateid = '$emailParent' ORDER BY".mysql_real_escape_string($orderby);
$resultUp = mysql_query($query_sv) or die("Query failed : " . mysql_error());

if(strcasecmp($orderby, "desc")==0){
$query_sv.= " DESC";
	}
else{
$query_sv.= " ASC";
    }
}
//default query
else{
$query_sv = "SELECT useremails.id, useremails.status ,email.id, email.subject, email.admin, email.date, email.emailtype, email.emailupdate,email.updateid,useremails.userid,email.service FROM useremails INNER JOIN email ON useremails.emailid = email.id WHERE useremails.userid = '$UserID' AND email.updateid = 'empty' ORDER BY date DESC"; }
$result = mysql_query($query_sv) or die("Query failed : " . mysql_error());
$sv = mysql_query($query_sv) or die(mysql_error());
$row_sv = mysql_fetch_assoc($sv);
$totalRows_sv = mysql_num_rows($sv);
}
?>

	//	$queryG = "SELECT DISTINCT groupname FROM groups WHERE userid = '$UserID'";
	//	$resultG = mysql_query($queryG) or die("Query failed : " . mysql_error());
	//
	//	while ($myrowG = mysql_fetch_row($resultG)) {
	//		if ($groupName == '') {
	//			$groupName = $myrowG[0];
	//		}
	//		else {
	//			$groupName = $groupName.', '.$myrowG[0];
	//		}
	//	}

	/* Printing results in HTML */
	printf("<td width=560 colspan=\"2\"><label for=\"name\"><a href="<? echo $_SERVER['PHP_SELF']."?orderby=Subject&sortby=$newsort";?>"<b>Subject</b></a></label></td>");
	printf("<td width=10 colspan=\"2\"><label for=\"name\"><a href="<? echo $_SERVER['PHP_SELF']."?orderby=Service Affected&sortby=$newsort";?>"<b>Service Affected</b></a></label></td>");
	printf("<td colspan=\"2\"><label for=\"name\"><a href="<? echo $_SERVER['PHP_SELF']."?orderby=Received&sortby=$newsort";?>"<b>Received</b></a></label></td>");
	printf("<td colspan=\"2\"><label for=\"name\"><a href="<? echo $_SERVER['PHP_SELF']."?orderby=Action&sortby=$newsort";?>"<b>Action</b></a></label></td></tr>");
	//printf("<tr><td colspan=\"2\" align=\"top\">");
	while ($myrow = mysql_fetch_row($result)) {
		$status = $myrow[1];
		$emailParent = $myrow[2];
		$emailupdate = $myrow[7];
		$emailservice= $myrow[10];
		// $queryUp = "SELECT useremails.id, useremails.status ,email.id, email.subject, email.admin, email.date, email.emailtype, email.emailupdate,email.updateid,useremails.userid FROM useremails INNER JOIN email ON useremails.emailid = email.id WHERE useremails.userid = '$UserID' AND email.updateid = '$emailParent' ORDER BY date DESC";
		// $resultUp = mysql_query($queryUp) or die("Query failed : " . mysql_error());

		if ($status == 'new') {
			printf("<tr><td colspan=\"2\"><label for=\"name\"><img src=\"images/icon_%s.gif\" width=\"16\" height=\"16\" border=\"0\" alt=\"%s\"></a>&nbsp;&nbsp;<a href=\"javascript:ViewEmail(%s,%s);\"><b>%s</b></a></label></td><td colspan=\"2\"><label for=\"name\">$emailservice</label></td><td colspan=\"2\"><label for=\"name\">%s</label></td></tr>", strtolower($myrow[6]),$myrow[6],$myrow[2],$myrow[9],$myrow[3],$myrow[5],$myrow[0]);
			while ($myrowUp = mysql_fetch_row($resultUp)) {
				$statusUp = $myrowUp[1];
				$emailupdateid = $myrowUp[2];
				$emailupdatesub = $myrowUp[3];
				$emailupdatedat = $myrowUp[5];
				$emailupdatetyp = $myrowUp[6];
				$emailparentid = $myrowUp[8];
				$emailupdateusr = $myrowUp[9];
				$emailupdateicon = strtolower($myrowUp[6]);
				//$emailupdatetyp = $myrowUp[6];
				if ($statusUp == 'new') {
					printf("<tr><td colspan=\"2\"><label for=\"name\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src=\"images/icon_$emailupdateicon.gif\" width=\"16\" height=\"16\" border=\"0\" alt=\"$emailupdateicon\"></a>&nbsp;&nbsp;<a href=\"javascript:ViewEmail($emailupdateid,$emailupdateusr);\"><b>$emailupdatesub</b></a>&nbsp;&nbsp;</label><font color=\"blue\" size=1></font></td><td colspan=\"2\"><label for=\"name\">$emailservice</label></td></tr>");
				}
				else {
					printf("<tr><td colspan=\"2\"><label for=\"name\">&nbsp;&nbsp;&nbsp;&nbsp;<img src=\"images/icon_$emailupdateicon.gif\" width=\"16\" height=\"16\" border=\"0\" alt=\"$emailupdateicon\"></a>&nbsp;&nbsp;<a href=\"javascript:ViewEmail($emailupdateid,$emailupdateusr);\">$emailupdatesub</a></label><font color=\"blue\" size=1></font></td><td colspan=\"2\"><label for=\"name\">$emailservice/label></td><td colspan=\"2\"><label for=\"name\">$emailupdatedat</label></td></tr>");
				}
			}
		}
		else {
			printf("<tr><td colspan=\"2\"><label for=\"name\"><img src=\"images/icon_%s.gif\" width=\"16\" height=\"16\" border=\"0\" alt=\"%s\"></a>&nbsp;&nbsp;<a href=\"javascript:ViewEmail(%s,%s);\">%s</a></label></td><td colspan=\"2\"><label for=\"name\">$emailservice</label></td><td colspan=\"2\"><label for=\"name\">%s</label></td></tr>", strtolower($myrow[6]),$myrow[6],$myrow[2],$myrow[9],$myrow[3],$myrow[5],$myrow[0]);
			while ($myrowUp = mysql_fetch_row($resultUp)) {
				$statusUp = $myrowUp[1];
				$emailupdateid = $myrowUp[2];
				$emailupdatesub = $myrowUp[3];
				$emailupdatedat = $myrowUp[5];
				$emailupdatetyp = $myrowUp[6];
				$emailparentid = $myrowUp[8];
				$emailupdateusr = $myrowUp[9];
				$emailupdateicon = strtolower($myrowUp[6]);
				//$emailupdatetyp = $myrowUp[6];
				if ($statusUp == 'new') {
					printf("<tr><td colspan=\"2\"><label for=\"name\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src=\"images/icon_$emailupdateicon.gif\" width=\"16\" height=\"16\" border=\"0\" alt=\"$emailupdateicon\"></a>&nbsp;&nbsp;<a href=\"javascript:ViewEmail($emailupdateid,$emailupdateusr);\"><b>$emailupdatesub</b></a></label>&nbsp;&nbsp;<font color=\"blue\" size=1></font></td><td colspan=\"2\"><label for=\"name\">$emailservice</label></td><td colspan=\"2\"><label for=\"name\">$emailupdatedat</label></td></tr>");
				}
				else {
					printf("<tr><td colspan=\"2\"><label for=\"name\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src=\"images/icon_$emailupdateicon.gif\" width=\"16\" height=\"16\" border=\"0\" alt=\"$emailupdateicon\"></a>&nbsp;&nbsp;<a href=\"javascript:ViewEmail($emailupdateid,$emailupdateusr);\">$emailupdatesub</a></label>&nbsp;&nbsp;<font color=\"blue\" size=1></font></td><td colspan=\"2\"><label for=\"name\">$emailservice</label></td><td colspan=\"2\"><label for=\"name\">$emailupdatedat</label></td></tr>");
				}
			}
		}
	}

	/* Free resultset */
	mysql_free_result($result);


}
else {
	/* Performing SQL query */
	$query = "SELECT id,subject,admin,date,emailtype,emailupdate,service FROM email WHERE updateid = 'empty' ORDER BY date DESC";
	$result = mysql_query($query) or die("Query failed : " . mysql_error());
	echo 'Welcome '.$UserNam.'!';
	/* Printing results in HTML */
	printf("<td width=560 colspan=\"2\"><label for=\"name\"><b>Subject</b></label></td>");
	printf("<td width=\"10\" colspan=\"2\"><label for=\"name\"><b>Service Affected</b></label></td>");
	printf("<td colspan=\"2\"><label for=\"name\"><b>Received</b></label></td>");
	printf("<td colspan=\"2\"><label for=\"name\"><b>Action</b></label></td></tr>");
	//printf("<tr><td colspan=\"2\" align=\"top\">");

	while ($myrow = mysql_fetch_row($result)) {
		$emailupdate = $myrow[5];
		$emailpaid = $myrow[0];
		$queryUp = "SELECT id,subject,admin,date,emailtype,emailupdate,service FROM email WHERE updateid = '$emailpaid' ORDER BY date DESC";
		$resultUp = mysql_query($queryUp) or die("Query failed : " . mysql_error());

		printf("<tr><td colspan=\"2\"><label for=\"name\"><img src=\"images/icon_%s.gif\" width=\"16\" height=\"16\" border=\"0\" alt=\"%s\"></a>&nbsp;&nbsp;<a href=\"javascript:ViewEmail(%s,'admin');\">%s</a></label></td><td colspan=\"2\"><label for=\"name\">%s</label></td><td colspan=\"2\"><label for=\"name\">%s</label></td><td colspan=\"2\"><label for=\"name\"><a href=\"updateEmail.php?update=%s\">update</a></label></td></tr>", strtolower($myrow[4]),$myrow[4],$myrow[0],$myrow[1],$myrow[6],$myrow[3],$myrow[0],$myrow[0]);
		while ($myrowUp = mysql_fetch_row($resultUp)) {
			$emailupdateid = $myrowUp[0];
			$emailupdatesub = $myrowUp[1];
			$emailupdatedat = $myrowUp[3];
			$emailupdatetyp = strtolower($myrowUp[4]);
			$emailupdateser = $myrowUp[6];

			printf("<tr><td colspan=\"2\"><label for=\"name\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src=\"images/icon_$emailupdatetyp.gif\" width=\"16\" height=\"16\" border=\"0\" alt=\"$emailupdatetyp\"></a>&nbsp;&nbsp;<a href=\"javascript:ViewEmail($emailupdateid,'admin');\">$emailupdatesub</a></label>&nbsp;&nbsp;<font color=\"blue\" size=1></font></td><td colspan=\"2\"><label for=\"name\">$emailupdateser</label></td><td colspan=\"2\"><label for=\"name\">$emailupdatedat</label></td></tr>");
		}

	}
	/* Free resultset */
	mysql_free_result($result);

}
/* Closing connection */
mysql_close($link);
?>

   </tr>
</table>

</form>
</div>
</body>
</html>
