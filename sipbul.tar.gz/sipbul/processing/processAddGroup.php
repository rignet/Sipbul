<html>

<HEAD>

<SCRIPT LANGUAGE="JavaScript">


</script>

</HEAD>

<BODY>

<?php

include ("dbconfig.php");
$link = mysql_connect($host,$usr,$pwd)
or die("Could not connect : " . mysql_error());


mysql_select_db($db) or die("Could not select database");

if (!$_POST['groupname'] == '') {
$nameCom = $_POST['groupname'];
}

$toEmails = $_POST['to'];
$toEmails = spliti(';', $toEmails);
$size=sizeof($toEmails);

if (!$_GET['id'] == '') {
$nameID = $_GET['id'];
}

if (!$_GET['delete'] == '') {
$nameCompany = $_GET['delete'];
}

for($j=0;$j<sizeof($toEmails);$j++)
{
	$email = "";
	$email = trim($toEmails[$j]);
	//echo $email.'<br>';
	if (ereg("[[:alnum:]]+@[[:alnum:]]+\.[[:alnum:]]+", $email)) {
		//echo $email.'=email<br>';
		$query1 = "SELECT DISTINCT username,id FROM users WHERE email = '$email'";
		$result1 = mysql_query($query1) or die("Query failed : " . mysql_error());
		while ($myrow1 = mysql_fetch_row($result1)) {
			$username = $myrow1[0];
			$userID = $myrow1[1];
			//echo 'hiiiiiiiiiii'.$userID.'<p>';
			//echo 'hiiiiiiiiiii'.$nameCom.'<p>';
			if (!$nameCom == '' && !$userID == '') {
				$queryIN1 = "INSERT INTO groups (groupname,username,email,userid) VALUES ('$nameCom','$username','$email','$userID')";
				mysql_query($queryIN1);

			}

		}
	}
	else {
		//echo $email.'=com<br>';
		$query2 = "SELECT DISTINCT username,email,id FROM users WHERE companyname = '$email'";
		$result2 = mysql_query($query2) or die("Query failed : " . mysql_error());
		while ($myrow2 = mysql_fetch_row($result2)) {
			$username = $myrow2[0];
			$email1 = $myrow2[1];
			$userID = $myrow2[2];
			//echo 'hiiiiiiiiiii'.$username.'<p>';
			//echo 'hiiiiiiiiiii'.$nameCom.'<p>';
			if (!$nameCom == '' && !$userID == '') {
				$queryIN2 = "INSERT INTO groups (groupname,username,email,userid) VALUES ('$nameCom','$username','$email1','$userID')";
				mysql_query($queryIN2);
			}

		}
	}

}



if (!$nameID == '') {

$query = "DELETE FROM groups WHERE id = '$nameID'";

mysql_query($query);

}

if (!$nameCompany == '') {

$query = "DELETE FROM groups WHERE groupname = '$nameCompany'";

mysql_query($query);

}

/* Closing connection */
mysql_close($link);

//header("Location: ../addAdmin.php");
?>

<script language="JavaScript">
    window.location = "../groupsManager.php"
</script>
</BODY>
</html>