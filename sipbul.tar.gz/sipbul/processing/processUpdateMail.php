<html>

<HEAD>

<SCRIPT LANGUAGE="JavaScript">


</script>

</HEAD>

<BODY>

<?php
include ("dbconfig.php");
$link = mysql_connect($host,$usr,$pwd)
or die("Could not connect : " . mysql_error());


mysql_select_db($db) or die("Could not select database");
$emailID = $_POST['emailID'];
$toEmails = $_POST['to'];
$toEmails = spliti(';', $toEmails);
$size=sizeof($toEmails);
//echo $size.'<p>';
//$nowDate = date("Ymd").time();
$nowDate = date("Ymd G:i:s");
//$nowDate = date("F j, Y, g:i a");
$from = $_POST['fromemail'];
$subject = $_POST['subject'];
$service1 = $_POST['service'];
$region1 = $_POST['region'];
$startdate1 = $_POST['startdate'];
$starttime1 = $_POST['starttime'];
$appduration1 = $_POST['appduration'];
$endtime1 = $_POST['endtime'];
$updatestr = 'yes';
$updatetext = $_POST['mailtext2'];
$starttimezone = $_POST['starttimezone'];
$endtimezone = $_POST['endtimezone'];
$unknownend = ($_POST['unknownend'] == "on" ? 1 : 0 );

$startdateNew = date("l F d Y H:i:s",strtotime($startdate1));
$endtimeNew = date("l F d Y H:i:s",strtotime($endtime1));

$service = '<b>The purpose of this notification is to advise customers of issues that may affect RigNet provided services on the following network:</b> '.$_POST['service'];
$region = '<br><br><b>Region(s) Affected: </b>'.$_POST['region'];
$startdate = '<br><br><b>Window Start Date and Time:</b> '.$startdateNew.' '.$starttimezone;
$starttime = '<br><br><b>Window Start Time:</b> '.$_POST['starttime'];

if ( $unknownend == 0 ) {
	$endtime = '<br><br><b>Window End Date and Time:</b> '.$endtimeNew.' '.$endtimezone;
	$appduration = '<br><br><b>Approximate Duration:</b> '.$_POST['appduration'];
}
else {
	$endtime = '<br><br><b>Window End Date and Time:</b> Unknown';
	$appduration = '<br><br><b>Approximate Duration:</b> Unknown';
}

//$endtime = '<br><br><b>Window End Date and Time:</b> '.$endtimeNew.' '.$endtimezone;
//$appduration = '<br><br><b>Approximate Duration:</b> '.$_POST['appduration'];
$reason = $_POST['mailtext1'];
$mailtext1 = '<br><br><b>Reason:</b> '.$_POST['mailtext1'];
$updatetext = '<b>Update:</b> '.$updatetext;
$mailtext2 = '';
$emailtype = $_POST['emailIcon'];
$severity = '<br><br><b>Severity: </b>'.$emailtype;

// jpr 5-9-05 Add the subject to the emailIcon and a '-' and Update
//$subject = $emailtype.'-'.$subject.' Update';
$subject = $subject.' UPDATE';

//$service = 'Please be advised of an interruption to the following RigNet service(s): '.$service;
//$region = 'Region(s) Affected: '.$region;
//$startdate = 'Start Date: '.$startdate;
//$mailtext = '<p>'.$service.$region.date("l dS of F Y h:i:s A",strtotime($startdate)).date("l dS of F Y h:i:s A",strtotime($endtime)).$appduration.$mailtext1.'<br><br>'.$mailtext2;
//$mailtext1 = str_replace($mailtext1, "'", "&#39;");
//$mailtext2 = str_replace($mailtext2, "'", "&#39;");
//$updatetext = str_replace($updatetext, "'", "&#39;");

$query = "SELECT DISTINCT disclaimer FROM disclaimer";
$result = mysql_query($query) or die("Query failed : " . mysql_error());

/* Printing results in HTML */
while ($myrow = mysql_fetch_row($result)) {
	$disclaimer = $myrow[0];
}

//$mailtext = '<p>'.$service.$severity.$region.$startdate.$endtime.$appduration.$mailtext1.'<br><br>'.$updatetext.'<br><br>'.$disclaimer;
$mailtext = '<p>'.$service.$severity.$region.$startdate.$endtime.$appduration.'<br><br>'.$updatetext.$mailtext1.'<br><br>'.$disclaimer;
echo $mailtext;
//echo '<p><p>date='.$nowDate;

// extra work, just run the all inclusive query after the update is in the db
// Find the integer interest level for this message.
//$query= "SELECT id FROM severities WHERE severityname = '$emailtype'";
//$result= mysql_query($query) or die("Query Failed : " . mysql_error() );
//$myrow= mysql_fetch_row($result);
//$updateinterestlevel= $myrow[0];

//$query = "SELECT outagetype FROM outageclass WHERE class = '$subject'";
//$result = mysql_query($query) or die("Query failed : " . mysql_error());
//
//while ($myrow = mysql_fetch_row($result)) {
//
//	$emailtype = $myrow[0];
//}

if (!$mailtext == '' && !$subject == '') {

/* Performing SQL query */

//echo '<p><p>date='.$nowDate;

	$query = "INSERT INTO email (subject,body,admin,date,emailtype,service,region,startdate,starttime,endtime,duration,reason,emailupdate,updatetext,updateid,starttimezone,endtimezone,unknownend) VALUES ('$subject','$mailtext','$from','$nowDate','$emailtype','$service1','$region1','$startdate1','$starttime1','$endtime1','$appduration1','$reason','$updatestr','$updatetext','$emailID','$starttimezone','$endtimezone','$unknownend')";

	mysql_query($query);

}
echo '<p><p>';

// Figure out the highest severity for this original and all it's updates
$querym= "SELECT severities.id FROM severities,email WHERE ((updateid=$emailID) or (email.id = $emailID)) and (severities.severityname = emailtype) order by severities.id desc";
$resultm= mysql_query($querym) or die("Query Failed : " . mysql_error() );
$myrow = mysql_fetch_row($resultm);
$maxmsginterestlevel= $myrow[0];

$query = "SELECT id,subject,body,admin FROM email WHERE date = '$nowDate'";
$result = mysql_query($query) or die("Query failed : " . mysql_error());

while ($myrow = mysql_fetch_row($result)) {

	$mailID = $myrow[0];
}
printf("<br><b>Emails Sent to:</b><br>");



$service1 = spliti(',', $service1);
for($j=0;$j<sizeof($service1);$j++)
{
	$serviceTemp = "";
	$serviceTemp = trim($service1[$j]);
	//echo $serviceTemp.'<br>';
//	$queryGr = "SELECT id,username,email,userid FROM groups WHERE groupname = '$serviceTemp'";
	$queryGr = "SELECT groups.id,groups.username,groups.email,groups.userid, users.interestlevel FROM groups,users WHERE (users.id = groups.userid) and (groupname = '$serviceTemp')";
	$resultGr = mysql_query($queryGr) or die("Query failed : " . mysql_error());
	while ($myrow = mysql_fetch_row($resultGr)) {
		$username = $myrow[1];
		$userID = $myrow[3];
		$email = $myrow[2];
		$userinterestlevel= $myrow[4];
		//echo $username.' < '.$email.' > '.'<br>';
		//echo $userID.'<br>';
		//echo "emailID : " . $emailID.'<br>';
		//echo 'UserInterest: ' . $userinterestlevel . ' MsgInterest: ' . $maxmsginterestlevel;
		if (!$mailID == '' && !$userID == '') {
			$queryBI= "select emailid, userid from useremails where emailid='$mailID' and userid='$userID'";
			$resultBI= mysql_query($queryBI) or die("Query failed : " . mysql_error());
			if ( !($junk= mysql_fetch_row($resultBI)) && ($userinterestlevel <= $maxmsginterestlevel) ) {
			
				$queryIN1 = "INSERT INTO useremails (emailid,userid,date) VALUES ('$mailID','$userID','$nowDate')";
				mysql_query($queryIN1);
				echo $username.' < '.$email.' > '.'<br>';
				mail($username." <".$email.">", $subject, $mailtext, "From: ".$Fromname." <".$Fromaddress.">\nContent-Type: text/html; charset=iso-8859-1");
			}
		}

	}
}

//echo $toEmails.'<p>';
$bccEmails = $_POST['bcc'];
//echo $_POST['name'];


/* Closing connection */
mysql_close($link);

?>
</BODY>
</html>
