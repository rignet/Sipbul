<html>

<HEAD>

<SCRIPT LANGUAGE="JavaScript">


</script>

</HEAD>

<BODY>

<?php

$toEmails = $_POST['to'];
$toEmails = spliti(';', $toEmails);
$size=sizeof($toEmails);
echo $size.'<p>';

for($j=0;$j<sizeof($toEmails);$j++)
{
   echo $toEmails[$j].'<p>';
}

//echo $toEmails.'<p>';
$bccEmails = $_POST['bcc'];
//echo $_POST['name'];

?>
<html> 
<head> 
</head> 
<body> 

<?php 
/* grabs the POST variables and puts them into variables that we can use */ 
$firstName=$_POST['firstName']; 
$lastName=$_POST['lastName']; 
$company=$_POST['company']; 
$email=$_POST['email']; 
$website=$_POST['website']; 
$countryCode=$_POST['countryCode']; 
$phone=$_POST['phone']; 
$phoneExt=$_POST['phoneExt']; 
$mobile=$_POST['mobile']; 
$fax=$_POST['fax']; 
$address=$_POST['address']; 
$city=$_POST['city']; 
$state=$_POST['state']; 
$country=$_POST['country']; 
$zipCode=$_POST['zipCode']; 
$heardAbout=$_POST['heardAbout']; 
$inquiring=$_POST['inquiring']; 

//---------VALIDATION--------> 
if($firstName){//----> CHECK input 
} 
else{ 
$error.="Please, go back and fill out your first name\n";//----> ERROR if no input 
} 

if($lastName){//----> CHECK input 
} 
else{ 
$error.="Please, go back and fill out your last name\n";//----> ERROR if no input 
} 

if($email){//----> CHECK input 
} 
else{ 
$error.="Please, go back and fill out your e-mail address\n";//----> ERROR if no input 
} 

if($phone){//----> CHECK input 
} 
else{ 
$error.="Please, go back and fill out your phone number\n";//----> ERROR if no input 
} 

if($address){//----> CHECK input 
} 
else{ 
$error.="Please, go back and fill out your mailing address\n";//----> ERROR if no input 
} 

if($city){//----> CHECK input 
} 
else{ 
$error.="Please, go back and fill out your city name\n";//----> ERROR if no input 
} 

if($zipCode){//----> CHECK input 
} 
else{ 
$error.="Please, go back and fill out your zip code\n";//----> ERROR if no input 
} 
//-------->ERROR FREE?? 
if($error==""){ 
echo "Thank you for inquiring about us! A receipt of your submission will be e-mailed to you almost immediately."; 
//---------------------------------- 
$mailContent="--------CONTACT--------\n" 
."First Name: ".$firstName."\n" 
."Last Name: ".$lastName."\n" 
."Company: ".$company."\n" 
."E-mail: ".$email."\n" 
//---------------------------------- 
$toAddress="forms@your_website_email.com"; /* change this! */ 
$subject="MyWebSite.com's Products'"; /* change this! */ 
$recipientSubject="MyWebSite.com's Contact Form"; /* change this! */ 
$receiptMessage = "Thank you ".$firstName." for inquiring about MyWebSite.com's Products!\n\n\nHere is what you submitted to us:\n\n" 
."--------CONTACT--------\n" 
."First Name: ".$firstName."\n" 
."Last Name: ".$lastName."\n" 
."Company: ".$company."\n" 
."E-mail: ".$email."\n" 
."Website: ".$website."\n\n--------PHONE--------\n" 
."Phone: ".$countryCode." ".$phone."\n" 
."Extension: ".$phoneExt."\n" 
."Fax: ".$fax."\n" 
."Mobile: ".$mobile."\n\n--------ADDRESS--------\n" 
."Street Address: ".$address."\n" 
."City: ".$city."\n" 
."State: ".$state."\n" 
."Country: ".$country."\n" 
."Zip Code: ".$zipCode."\n\n--------INFO--------\n" 
."Where did you hear about us? ".$heardAbout."\n" 
."Inquiring About: ".$inquiring."\n" 
//---------------------------------- 
mail($email, $subject, $receiptMessage,"From:$toAddress"); 
//---------------------------------- 
mail($toAddress,$recipientSubject,$mailContent,"From:$email"); 
//--->echo $mailContent; 

////////////////////////////////////////CONNECT TO MYSQL DB////////////////////
include ("dbconfig.php");
$link = mysql_connect($host,$usr,$pwd)
or die("Could not connect : " . mysql_error());

//echo "Connected successfully";
mysql_select_db($db) or die("Could not select database");

//EXECUTE QUERY ---> 
$query="INSERT INTO generalContact ( 
firstName, 
lastName, 
company, 
email, 
website, 
countryCode, 
phone, 
phoneExt, 
mobile, 
fax, 
address, 
city, 
state, 
country, 
zipCode, 
heardAbout, 
inquiringOn) 
VALUES( 
'".$firstName."', 
'".$lastName."', 
'".$company."', 
'".$email."', 
'".$website."', 
'".$countryCode."', 
'".$phone."', 
'".$phoneExt."', 
'".$mobile."', 
'".$fax."', 
'".$address."', 
'".$city."', 
'".$state."', 
'".$country."', 
'".$zipCode."', 
'".$heardAbout."', 
'".$inquiring."')"; 
//////-----> 
$result=mysql_query($query) or die("Error in query:".mysql_error()); 
//if ($result) 
//echo mysql_affected_rows()." row inserted into the database effectively."; 

//CLOSE CONNECTION ---> 
mysql_close($connection); 

///////////////////////////////////////////////////////////////////////////////////
 } 
else{ 

print "Sorry, but the form cannot be sent until the fields indicated are filled out completely - \n"; 
print "$error\n"; 
print "\n"; 
print "\n"; 
print "Please use your \"Back\" button to return to the form to correct the omissions.Thank you.\n"; 
} 

?> 
</body> 
</html> 


