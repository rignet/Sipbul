<html>

<HEAD>

<SCRIPT LANGUAGE="JavaScript">


</script>

</HEAD>

<BODY>

<?php

include ("dbconfig.php");
$link = mysql_connect($host,$usr,$pwd)
or die("Could not connect : " . mysql_error());


mysql_select_db($db) or die("Could not select database");

//echo( $_POST['origcompanyname'] );
//echo('<br>');
//echo( $_POST['origusername'] );
//echo('<br>');
//echo( $_POST['origemail'] );
//echo('<br>');
//echo( $_POST['origloginName'] );
//echo('<br>');
//echo( $_POST['origpassword'] );
//echo('<br>');


//echo( $_POST['id'] );
//echo('<br>');
//echo( $_POST['comname'] );
//echo('<br>');
//echo( $_POST['name'] );
//echo('<br>');
//echo( $_POST['email'] );
//echo('<br>');
//echo( $_POST['loginname'] );
//echo('<br>');
//echo( $_POST['loginpass'] );
//echo('<br>');


if (!$_POST['id'] == '') {
$id = $_POST['id'];
}

if (!$_POST['comname'] == '') {
$newcomname = $_POST['comname'];
}

if (!$_POST['name'] == '') {
$newname = $_POST['name'];
}

if (!$_POST['email'] == '') {
$newemail = $_POST['email'];
}

if (!$_POST['loginname'] == '') {
$newloginname = $_POST['loginname'];
}

if (!$_POST['loginpass'] == '') {
$newloginpass = $_POST['loginpass'];
}

if (!$_POST['interest'] == '') {
$newinterest = $_POST['interest'];
}

// Get the numeric interest level for the user from the severities table

$query= "SELECT id FROM severities WHERE severityname = '$newinterest'";

$result= mysql_query($query) or die("Query Failed : " . mysql_error() );
$myrow= mysql_fetch_row($result);
$interestlevel= $myrow[0];

if (!$id == '' ) {

	/* Performing SQL query */

	$query = "UPDATE users SET companyname= '$newcomname',username='$newname'";
	$query .= ",email='$newemail',loginName='$newloginname',interestlevel='$interestlevel' ";
	$query .= "WHERE id = '$id' ";

	//die($query);
	//echo($query);

	mysql_query($query);

	// 	Update the Groups table with the new information
	$query = "UPDATE groups SET username= '$newname',email='$newemail' ";
	$query .= "WHERE userid = '$id' ";

	mysql_query($query);


}

/* Closing connection */
mysql_close($link);

?>

<script language="JavaScript">
    window.location = "../userManager.php"
</script>
</BODY>
</html>
