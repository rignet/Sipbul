<html>

<HEAD>

<SCRIPT LANGUAGE="JavaScript">


</script>

</HEAD>

<BODY>

<?php

include ("dbconfig.php");
$link = mysql_connect($host,$usr,$pwd)
or die("Could not connect : " . mysql_error());


mysql_select_db($db) or die("Could not select database");

if (!$_POST['name'] == '') {
$nameFull = $_POST['name'];
}


if (!$_GET['delete'] == '') {
$nameID = $_GET['delete'];
}

if (!$nameFull == '') {

/* Performing SQL query */

$query = "INSERT INTO stratosservices (service) VALUES ('$nameFull')";

mysql_query($query);


}

if (!$nameID == '') {

$query = "DELETE FROM stratosservices WHERE id = '$nameID'";

mysql_query($query);

}


/* Closing connection */
mysql_close($link);

//header("Location: ../stratosServices.php");
?>
<script language="JavaScript">
    window.location = "../stratosServices.php"
</script>
</BODY>
</html>
