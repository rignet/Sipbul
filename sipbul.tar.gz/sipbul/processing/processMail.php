<html>

<HEAD>

<SCRIPT LANGUAGE="JavaScript">


</script>

</HEAD>

<BODY>

<?php
include ("dbconfig.php");
$link = mysql_connect($host,$usr,$pwd)
or die("Could not connect : " . mysql_error());


mysql_select_db($db) or die("Could not select database");
$toEmails = $_POST['to'];
$toEmails = spliti(';', $toEmails);
$size=sizeof($toEmails);
//echo $size.'<p>';
//$nowDate = date("Ymd").time();
$nowDate = date("Ymd G:i:s");
//$nowDate = date("F j, Y, g:i a");
$from = $_POST['fromemail'];
$subject = $_POST['subject'];
$service1 = $_POST['service'];
//echo 'Service:'.$service1.'<br>';
$region1 = $_POST['region'];
$startdate1 = $_POST['startdate'];
$starttime1 = $_POST['starttime'];
$appduration1 = $_POST['appduration'];
$endtime1 = $_POST['endtime'];
$starttimezone = $_POST['starttimezone'];
$endtimezone = $_POST['endtimezone'];
$unknownend = ($_POST['unknownend'] == "on" ? 1 : 0 );

$startdateNew = date("l F d Y H:i:s",strtotime($startdate1));
$endtimeNew = date("l F d Y H:i:s",strtotime($endtime1));

$service = '<b>The purpose of this notification is to advise customers of issues that may affect RigNet provided services on the following network:</b> '.stripslashes($_POST['service']);
$region = '<br><br><b>Region(s) Affected: </b>'.stripslashes($_POST['region']);
$startdate = '<br><br><b>Window Start Date and Time:</b> '.$startdateNew.' '.$starttimezone;
$starttime = '<br><br><b>Window Start Time:</b> '.$_POST['starttime'];

if ( $unknownend == 0 ) {
	$endtime = '<br><br><b>Window End Date and Time:</b> '.$endtimeNew.' '.$endtimezone;
	$appduration = '<br><br><b>Approximate Duration:</b> '.$_POST['appduration'];
}
else {
	$endtime = '<br><br><b>Interruption Window End Date and Time:</b> Unknown';
	$appduration = '<br><br><b>Approximate Duration:</b> Unknown';
}
$reason = $_POST['mailtext1'];
$mailtext1 = '<br><br><b>Reason:</b> '.$_POST['mailtext1'];
$mailtext2 = $_POST['mailtext2'];
$emailtype = $_POST['emailIcon'];
//jpr 5-9-05 echo '['.$emailtype.']<p>';
$severity = '<br><br><b>Severity: </b>'.$emailtype;

// jpr 5-9-05 Add the subject to the emailIcon and a '-'
//$subject = $emailtype.'-'.$subject;

//$service = 'Please be advised of an interruption to the following RigNet service(s): '.$service;
//$region = 'Region(s) Affected: '.$region;
//$startdate = 'Start Date: '.$startdate;
$query = "SELECT DISTINCT disclaimer FROM disclaimer";
$result = mysql_query($query) or die("Query failed : " . mysql_error());

/* Printing results in HTML */
while ($myrow = mysql_fetch_row($result)) {
	$disclaimer = $myrow[0];
	//$emailbody = $emailbody.'<br>'.$disclaimer;
}
//$disclaimer = str_replace($disclaimer, "'", "&#39;");
//$mailtext1 = str_replace($_POST['mailtext1'], "'", "&#39;");
//$mailtext2 = str_replace($mailtext2, "'", "&#39;");
//$mailtext1 = '<br><br><b>Reason:</b> '.$mailtext1;
$mailtext = '<p>'.$service.$severity.$region.$startdate.$endtime.$appduration.$mailtext1.'<br><br>'.$mailtext2.'<br>'.$disclaimer;

echo $subject.'<p><p>';
echo $mailtext.'<p>';



// Find the integer interest level for this message.
$query= "SELECT id FROM severities WHERE severityname = '$emailtype'";
$result= mysql_query($query) or die("Query Failed : " . mysql_error() );
$myrow= mysql_fetch_row($result);
$interestlevel= $myrow[0];

//echo 'Unknown Status:'.$unknownend.'<p>';
//echo '<p><p>date='.$nowDate;

// jpr 5-9-05 Not looking up outage type anymore
//$query = "SELECT outagetype FROM outageclass WHERE class = '$subject'";
//$result = mysql_query($query) or die("Query failed : " . mysql_error());
//
//while ($myrow = mysql_fetch_row($result)) {
//
//	$emailtype = $myrow[0];
//}

if (!$mailtext == '' && !$subject == '') {

/* Performing SQL query */

//echo '<p><p>date='.$nowDate;

$query = "INSERT INTO email (subject,body,admin,date,emailtype,service,region,startdate,starttime,endtime,duration,reason,starttimezone,endtimezone,unknownend) VALUES ('$subject','$mailtext','$from','$nowDate','$emailtype','$service1','$region1','$startdate1','$starttime1','$endtime1','$appduration1','$reason','$starttimezone','$endtimezone','$unknownend')";

	mysql_query($query);

}
//echo $query.'<p><p>';

//$nowDate = "2005-01-12 17:29:56";
/* Performing SQL query */
$query = "SELECT id,subject,body,admin FROM email WHERE date = '$nowDate'";
$result = mysql_query($query) or die("Query failed : " . mysql_error());

while ($myrow = mysql_fetch_row($result)) {

	$mailID = $myrow[0];
}
//echo 'Email ID '.$mailID.'<p><p>';
printf("<br><b>Emails Sent to:</b><br>");



$service1 = spliti(',', $service1);
for($j=0;$j<sizeof($service1);$j++)
{
	$serviceTemp = "";
	$serviceTemp = trim($service1[$j]);
	//echo 'Looking for:['.$serviceTemp.']<br>';
	$queryGr = "SELECT groups.id,groups.username,groups.email,groups.userid, users.interestlevel FROM groups,users WHERE (users.id = groups.userid) and (groupname = '$serviceTemp')";
	$resultGr = mysql_query($queryGr) or die("Query failed : " . mysql_error());
	while ($myrow = mysql_fetch_row($resultGr)) {
		//echo 'Matched:'.$myrow;
		$username = $myrow[1];
		$userID = $myrow[3];
		$email = $myrow[2];
		$userinterestlevel= $myrow[4];
		//echo $username.' < '.$email.' > '.'<br>';
		//echo $userID.'<br>';
		//echo $email.'<br>';
		//echo 'UserInterest: ' . $userinterestlevel . ' MsgInterest: ' . $interestlevel;
		if (!$mailID == '' && !$userID == '') {
			$queryBI= "select emailid, userid from useremails where emailid='$mailID' and userid='$userID'";
			$resultBI= mysql_query($queryBI) or die("Query failed : " . mysql_error());
			if ( !($junk= mysql_fetch_row($resultBI)) && ($userinterestlevel <= $interestlevel) ) {
			
				$queryIN1 = "INSERT INTO useremails (emailid,userid,date) VALUES ('$mailID','$userID','$nowDate')";
				mysql_query($queryIN1);
				echo $username.' < '.$email.' > '.'<br>';
				mail($username." <".$email.">", $subject, $mailtext, "From: ".$Fromname." <".$Fromaddress.">\nContent-Type: text/html; charset=iso-8859-1");
			}
		}
		
	}
}

//echo $toEmails.'<p>';
$bccEmails = $_POST['bcc'];
//echo $_POST['name'];


/* Closing connection */
mysql_close($link);

?>
</BODY>
</html>
