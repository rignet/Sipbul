<html>

<HEAD>

<SCRIPT LANGUAGE="JavaScript">


</script>

</HEAD>

<BODY>

<?php

include ("dbconfig.php");
$link = mysql_connect($host,$usr,$pwd)
or die("Could not connect : " . mysql_error());


mysql_select_db($db) or die("Could not select database");

if (!$_POST['name'] == '') {
$nameFull = $_POST['name'];
}

//if (!$_POST['emailIcon'] == '') {
//$emailIcon = $_POST['emailIcon'];
//}


if (!$_GET['delete'] == '') {
$nameID = $_GET['delete'];
}

if (!$nameFull == '') {

/* Performing SQL query */

$query = "INSERT INTO outageclass (class,outagetype) VALUES ('$nameFull','')";

mysql_query($query);

}

if (!$nameID == '') {

$query = "DELETE FROM outageclass WHERE id = '$nameID'";

mysql_query($query);

}


/* Closing connection */
mysql_close($link);

//header("Location: ../outageClass.php");
?>
<script language="JavaScript">
    window.location = "../outageClass.php"
</script>
</BODY>
</html>
