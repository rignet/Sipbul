<html>

<HEAD>

<SCRIPT LANGUAGE="JavaScript">


</script>

</HEAD>

<BODY>

<?php

include ("dbconfig.php");
$link = mysql_connect($host,$usr,$pwd)
or die("Could not connect : " . mysql_error());


mysql_select_db($db) or die("Could not select database");


if (!$_GET['userID'] == '') {
$userID = $_GET['userID'];

}

if (!$_GET['delete'] == '') {
$emailID = $_GET['delete'];
}

echo $emailID.$userID;

if (!$emailID == '' && !$userID == '') {

	/* Performing SQL query */

//	$query = "DELETE FROM useremails WHERE id = '$emailID' AND userid = '$userID'";

	mysql_query($query);


}
else {
	if (!$emailID == '') {

//		$query = "DELETE FROM useremails WHERE emailid = '$emailID'";
//
//		mysql_query($query);
//
//		$query = "DELETE FROM email WHERE id = '$emailID'";
//
//		mysql_query($query);
//
//		$query = "UPDATE email SET updateid = 'empty' WHERE updateid = '$emailID'";
//
//		mysql_query($query);
		$query = "INSERT *


	}
}

/* Closing connection */
mysql_close($link);

//header("Location: ../addAdmin.php");
?>
<script language="JavaScript">
    window.location = "../main.php"
</script>
</BODY>
</html>
