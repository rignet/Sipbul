<html>

<HEAD>

<SCRIPT LANGUAGE="JavaScript">

</script>

</HEAD>

<?php

include ("dbconfig.php");
$link = mysql_connect($host,$usr,$pwd)
or die("Could not connect : " . mysql_error());


mysql_select_db($db) or die("Could not select database");

if (!$_POST['comname'] == '') {
$nameCom = $_POST['comname'];
}

if (!$_POST['name'] == '') {
$nameFull = $_POST['name'];
}

if (!$_POST['email'] == '') {
$linkText = $_POST['email'];

}

if (!$_GET['id'] == '') {
$nameID = $_GET['id'];
}

if (!$_GET['delete'] == '') {
$nameCompany = $_GET['delete'];
}

if (!$_GET['loginpass'] == '') {
$loginpass = $_GET['loginpass'];
}

if (!$_POST['loginname'] == '') {
$loginname = $_POST['loginname'];
}

if (!$_POST['interest'] == '') {
$interest = $_POST['interest'];
}

// Get the numeric interest level for the user from the severities table

$query= "SELECT id FROM severities WHERE severityname = '$interest'";

$result= mysql_query($query) or die("Query Failed : " . mysql_error() );
$myrow= mysql_fetch_row($result);
$interestlevel= $myrow[0];

if (!$nameFull == '' && !$linkText == '') {

/* Performing SQL query */

$query = "INSERT INTO users (companyname,username,email,loginName,password,interestlevel) VALUES ('$nameCom','$nameFull','$linkText','$loginname','$loginpass', '$interestlevel')";

mysql_query($query);

}

if (!$nameID == '') {

	$query = "DELETE FROM users WHERE id = '$nameID'";
	mysql_query($query);

	$query = "DELETE FROM groups WHERE userid = '$nameID'";
	mysql_query($query);

	$query = "DELETE FROM useremails WHERE userid = '$nameID'";
	mysql_query($query);
}

if (!$nameCompany == '') {

$query = "DELETE FROM users WHERE companyname = '$nameCompany'";

mysql_query($query);

}

/* Closing connection */
mysql_close($link);

//header("Location: ../addAdmin.php");
?>
<BODY>
<script language="JavaScript">
    window.location = "../userManager.php"
</script>
</BODY>
</html>
