<html>

<HEAD>

<SCRIPT LANGUAGE="JavaScript">


</script>

</HEAD>

<BODY>

<?php

include ("dbconfig.php");
$link = mysql_connect($host,$usr,$pwd)
or die("Could not connect : " . mysql_error());


mysql_select_db($db) or die("Could not select database");

if (!$_POST['name'] == '') {
$nameFull = $_POST['name'];
}

if (!$_POST['email'] == '') {
$linkText = $_POST['email'];

}

if (!$_POST['admintype'] == '') {
$admintype = $_POST['admintype'];

}

if (!$_POST['id'] == '') {
$nameID = $_POST['id'];
}

if (!$nameFull == '' && !$linkText == '') {

/* Performing SQL query */

$query = "UPDATE admin SET adminname = '$nameFull' ,email = '$linkText', admintype = '$admintype' WHERE id = '$nameID'";

mysql_query($query);

}



/* Closing connection */
mysql_close($link);

//header("Location: ../addAdmin.php");
?>
<script language="JavaScript">
    window.location = "../adminManager.php"
</script>
</BODY>
</html>