<html>

<HEAD>

<SCRIPT LANGUAGE="JavaScript">


</script>

</HEAD>

<BODY>

<?php
include ("dbconfig.php");
$link = mysql_connect($host,$usr,$pwd)
or die("Could not connect : " . mysql_error());


mysql_select_db($db) or die("Could not select database");
$toEmails = $_POST['to'];
$toEmails = spliti(';', $toEmails);
$size=sizeof($toEmails);
//echo $size.'<p>';
//$nowDate = date("Ymd").time();
$nowDate = date("Ymd G:i:s");
//$nowDate = date("F j, Y, g:i a");
$from = $_POST['fromemail'];
$subject = $_POST['subject'];
$service1 = $_POST['service'];
$region1 = $_POST['region'];
$startdate1 = $_POST['startdate'];
$starttime1 = $_POST['starttime'];
$appduration1 = $_POST['appduration'];
$endtime1 = $_POST['endtime'];

$service = '<b>Please be advised of an interruption to the following Stratos service(s):</b> '.$_POST['service'];
$region = '<br><br><b>Region(s) Affected: </b>'.$_POST['region'];
$startdate = '<br><br><b>Service Affected:<br>Start Date:</b> '.$_POST['startdate'];
$starttime = '<br><br><b>Interruption Window Start Time:</b> '.$_POST['starttime'];
$endtime = '<br><br><b>Interruption Window End Time:</b> '.$_POST['endtime'];
$appduration = '<br><br><b>Approximate Duration:</b> '.$_POST['appduration'];
$reason = $_POST['mailtext1'];
$mailtext1 = '<br><b>Reason:</b> '.$_POST['mailtext1'];
$mailtext2 = $_POST['mailtext2'];
$emailtype = $_POST['emailIcon'];

//$service = 'Please be advised of an interruption to the following Stratos service(s): '.$service;
//$region = 'Region(s) Affected: '.$region;
//$startdate = 'Start Date: '.$startdate;
$mailtext = '<p>'.$service.$region.$startdate.$starttime.$endtime.$appduration.$mailtext1.'<br><br>'.$mailtext2;
echo $mailtext;
echo '<p><p>date='.$nowDate;

$query = "SELECT outagetype FROM outageclass WHERE class = '$subject'";
$result = mysql_query($query) or die("Query failed : " . mysql_error());

while ($myrow = mysql_fetch_row($result)) {

	$emailtype = $myrow[0];
}

if (!$mailtext == '' && !$subject == '') {

/* Performing SQL query */

//echo '<p><p>date='.$nowDate;

	$query = "INSERT INTO email (subject,body,admin,date,emailtype,service,region,startdate,starttime,endtime,duration,reason) VALUES ('$subject','$mailtext','$from','$nowDate','$emailtype','$service1','$region1','$startdate1','$starttime1','$endtime1','$appduration1','$reason')";

	mysql_query($query);

}
echo '<p><p>';

//$nowDate = "2005-01-12 17:29:56";
/* Performing SQL query */
$query = "SELECT id,subject,body,admin FROM email WHERE date = '$nowDate'";
$result = mysql_query($query) or die("Query failed : " . mysql_error());

while ($myrow = mysql_fetch_row($result)) {

	$mailID = $myrow[0];
}
printf("<br><b>Emails Sent to</b><br>".$mailID);

$queryGr = "SELECT DISTINCT id,groupname,email FROM groups ORDER BY groupname";
$resultGr = mysql_query($queryGr) or die("Query failed : " . mysql_error());

while ($myrow = mysql_fetch_row($result)) {
	$serviceVal = $myrow[1];
	$services = strstr($service,$serviceVal);
	if(!$services == '') {

		for($j=0;$j<sizeof($toEmails);$j++)
		{
			$email = "";
			$email = trim($toEmails[$j]);
			echo $email.'<br>';
			if (ereg("[[:alnum:]]+@[[:alnum:]]+\.[[:alnum:]]+", $email)) {
				//echo $email.'=email<br>';
				$query1 = "SELECT DISTINCT username,id FROM users WHERE email = '$email'";
				$result1 = mysql_query($query1) or die("Query failed : " . mysql_error());
				while ($myrow1 = mysql_fetch_row($result1)) {
					$username = $myrow1[0];
					$userID = $myrow1[1];
					//echo 'hiiiiiiiiiii'.$userID.'<p>';
					if (!$mailID == '' && !$userID == '') {
						$queryIN1 = "INSERT INTO useremails (emailid,userid,date) VALUES ('$mailID','$userID','$nowDate')";
						mysql_query($queryIN1);
					}
					//mail($username." <".$email.">", $subject, $mailtext, "From: ".$Fromname." <".$Fromaddress.">\nContent-Type: text/html; charset=iso-8859-1");
				}
			}
			else {
				//echo $email.'=com<br>';
				$query2 = "SELECT DISTINCT username,email,id FROM users WHERE companyname = '$email'";
				$result2 = mysql_query($query2) or die("Query failed : " . mysql_error());
				while ($myrow2 = mysql_fetch_row($result2)) {
					$username = $myrow2[0];
					$email1 = $myrow2[1];
					$userID = $myrow2[2];
					//echo 'hiiiiiiiiiii'.$username.'<p>';
					if (!$mailID == '' && !$userID == '') {
						$queryIN2 = "INSERT INTO useremails (emailid,userid,date) VALUES ('$mailID','$userID','$nowDate')";
						mysql_query($queryIN2);
					}
					//mail($username." <".$email1.">", $subject, $mailtext, "From: ".$Fromname." <".$Fromaddress.">\nContent-Type: text/html; charset=iso-8859-1");
				}
				$query3 = "SELECT DISTINCT username,email,userid FROM groups WHERE groupname = '$email'";
				$result3 = mysql_query($query3) or die("Query failed : " . mysql_error());
				while ($myrow2 = mysql_fetch_row($result3)) {
					$username = $myrow2[0];
					$email1 = $myrow2[1];
					$userID = $myrow2[2];
					//echo 'hiiiiiiiiiii'.$username.'<p>';
					if (!$mailID == '' && !$userID == '') {
						$queryIN2 = "INSERT INTO useremails (emailid,userid,date) VALUES ('$mailID','$userID','$nowDate')";
						mysql_query($queryIN2);
					}
					//mail($username." <".$email1.">", $subject, $mailtext, "From: ".$Fromname." <".$Fromaddress.">\nContent-Type: text/html; charset=iso-8859-1");
				}

			}
		   //mail($toAddress,$recipientSubject,$mailContent,"From:$email");

		   //mail($username." <".$email.">", $subject, $mailtext, "From: ".$Fromname." <".$Fromaddress.">\nContent-Type: text/html; charset=iso-8859-1")
		}
	}
}

//echo $toEmails.'<p>';
$bccEmails = $_POST['bcc'];
//echo $_POST['name'];


/* Closing connection */
mysql_close($link);

?>
</BODY>
</html>
