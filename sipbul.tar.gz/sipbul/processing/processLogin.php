<?php
//session_start();
include ("dbconfig.php");
$link = mysql_connect($host,$usr,$pwd)
or die("Could not connect : " . mysql_error());


mysql_select_db($db) or die("Could not select database");

if (!$_POST['email'] == '') {
$email = $_POST['email'];
}


if (!$_POST['password'] == '') {
$password = $_POST['password'];
}

if (!$email == '') {

/* Performing SQL query */

$query = "SELECT adminname,admintype,password,id,email FROM admin WHERE email = '$email'";

$result = mysql_query($query) or die("Query failed : " . mysql_error());

while ($myrow = mysql_fetch_row($result)) {
	$password2 = $myrow[2];
	$admintype = $myrow[1];
	$adminname = $myrow[0];
	$adminid = $myrow[3];
	$adminemail = $myrow[4];
	if ($password == $password2) {
		$_SESSION['useremail']=$email;
		$_SESSION['usertype']=$admintype;
		$_SESSION['username']=$adminname;

		setcookie("cookemail", $adminemail, time()+60*60*24*100, "/");
		setcookie("cooktype", $admintype, time()+60*60*24*100, "/");
		setcookie("cookname", $adminname, time()+60*60*24*100, "/");
		setcookie("cookid", $adminid, time()+60*60*24*100, "/");
		//setcookie("cookname", $adminname);
		echo "<script>window.location=\"../loginSuccess.php\"</script>";

	}
	else {
		echo "<script>window.location=\"../index.php?login=failed\"</script>";
		//echo "<font color=red>Invalid Login/Password!!</font>";
	}

}
	if ($password2 == '') {
		//echo "<script>window.location=\"../index.php?login=failed\"</script>";
	}
}

$UserNam = $HTTP_COOKIE_VARS["cookname"];
$UserNam   = count($UserNam);


if ($UserNam < 1) {
	//echo "<script>window.location=\"../index.php\"</script>";
}

/* Closing connection */
mysql_close($link);


?>