<?php
$usr = "jeakins"; // The database user name
$pwd = "totoromei"; //The database password
$db = "sipbul"; //The name of the database
$host = "localhost"; // most probably the host name is 'localhost', or try 127.0.0.1
$Fromaddress = "operations.inbox@rig.net";  // Change this to whatever 'from' information you'd like to give.
$Fromname = "RigNet Admin";  // Change this to whatever 'from' information you'd like to give.
//$subject = ""; // The subject as you want it to appear in the recipient's mailclient.
?>
