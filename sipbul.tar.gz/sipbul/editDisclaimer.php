<html>
<head>

<link rel="STYLESHEET" type="text/css" href="styles.css">
<link rel="STYLESHEET" type="text/css" href="tree.css">

<script language="Javascript">
<!--
if (document.images) {
//on buttons
	imgBoldon = new Image();
	imgBoldon.src = "images/bold_on.gif";
	imgItalicon = new Image();
	imgItalicon.src = "images/italic_on.gif";
	imgUnderlineon = new Image();
	imgUnderlineon.src = "images/underline_on.gif";
	imgOrderedListon = new Image();
	imgOrderedListon.src = "images/orderedlist_on.gif";
	imgUnorderedListon = new Image();
	imgUnorderedListon.src = "images/unorderedlist_on.gif";
	imgAlignLefton = new Image();
	imgAlignLefton.src = "images/alignleft_on.gif";
	imgAlignCenteron = new Image();
	imgAlignCenteron.src = "images/aligncenter_on.gif";
	imgAlignRighton = new Image();
	imgAlignRighton.src = "images/alignright_on.gif";
	imgInsertLinkon = new Image();
	imgInsertLinkon.src = "images/insertlink_on.gif";
	imgClearHtmlon = new Image();
	imgClearHtmlon.src = "images/clearhtml_on.gif";

//off buttons
	imgBoldoff = new Image();
	imgBoldoff.src = "images/bold_off.gif";
	imgItalicoff = new Image();
	imgItalicoff.src = "images/italic_off.gif";
	imgUnderlineoff = new Image();
	imgUnderlineoff.src = "images/underline_off.gif";
	imgOrderedListoff = new Image();
	imgOrderedListoff.src = "images/orderedlist_off.gif";
	imgUnorderedListoff = new Image();
	imgUnorderedListoff.src = "images/unorderedlist_off.gif";
	imgAlignLeftoff = new Image();
	imgAlignLeftoff.src = "images/alignleft_off.gif";
	imgAlignCenteroff = new Image();
	imgAlignCenteroff.src = "images/aligncenter_off.gif";
	imgAlignRightoff = new Image();
	imgAlignRightoff.src = "images/alignright_off.gif";
	imgInsertLinkoff = new Image();
	imgInsertLinkoff.src = "images/insertlink_off.gif";
	imgClearHtmloff = new Image();
	imgClearHtmloff.src = "images/clearhtml_off.gif";
}

function changeImages() {
	if (document.images) {
		for (var i=0; i<changeImages.arguments.length; i+=2) {
			document[changeImages.arguments[i]].src = eval(changeImages.arguments[i+1] + ".src");
		}
	}
}

function StoreCaret (textEl) {
	var optionObject;
	optionObject = eval(textEl);

	if (optionObject.createTextRange) {
		optionObject.caretPos = document.selection.createRange().duplicate();
	}
}

function InsertAddLink (textEl,strType) {
	var url = prompt('Enter the URL location :','http:\/\/')
	var optionObject;
	optionObject = eval(textEl);
	if (url != null) {
		var strResultText = "";
		strResultText = (document.all) ? document.selection.createRange().text :
		document.frmContentTemplateStoryEditor.text.value = strResultText ;
		document.selection.createRange().text = "";
		var caretPos = optionObject.caretPos;
		caretPos.text = caretPos.text.charAt(caretPos.text.length) == ' ' ? strOpen + ' ':
		'<a href=\"' + url + '\">' + strResultText + '</a>';
	}
	window.status=strType;
}

function InsertAtCursor (textEl,strOpen,strClose,strType) {
	var strResultText = "";
	var optionObject;
	optionObject = eval(textEl);
	strResultText = (document.all) ? document.selection.createRange().text :
	document.frmContentTemplateStoryEditor.text.value = strResultText ;
	document.selection.createRange().text = "";
	if (optionObject.createTextRange && optionObject.caretPos) {
		var caretPos = optionObject.caretPos;
		caretPos.text = caretPos.text.charAt(caretPos.text.length) == ' ' ? strOpen + ' ':
		strOpen + strResultText + strClose;
	}
	window.status=strType;
}

function InsertLists(textEl,strOpen,strClose,strDivider,strType) {
	var strResultText = "";
	var optionObject;
	optionObject = eval(textEl);
	strResultText = (document.all) ? document.selection.createRange().text :
	document.frmContentTemplateStoryEditor.text.value = strResultText ;
	var strOutPut = "";
	document.selection.createRange().text = "";
	if (optionObject.createTextRange && optionObject.caretPos) {
		for (var i = 0; i < strResultText.length; i++) {
			if ((strResultText.charCodeAt(i) == 13) && (strResultText.charCodeAt(i + 1) == 10)) {
				i++;
				strOutPut += "\r\n" + strDivider;
			}
			else {
				strOutPut += strResultText.charAt(i);
			}
		}
		var caretPos = optionObject.caretPos;
		caretPos.text = caretPos.text.charAt(caretPos.text.length) == ' ' ? strOpen + ' ':
		strOpen + strDivider + strOutPut + strClose + "\r\n";
	}
	window.status=strType;
}

function ClearTags(textEl,strType) {
	var optionObject;
	optionObject = eval(textEl);
	if (!confirm("Are you sure you want to delete the HTML in the " + strType + "?")) {
		optionObject = optionObject.value.replace(/<[^>]*>/g,'');
	//	document.frmContentTemplateStoryEditor.strContentTemplateHeader.value = textEl.replace(/<[^>]*>/g,'');
	}
}

function ConvertBR(input) {
// Converts carriage returns
// to <BR> for display in HTML
	var output = "";
	for (var i = 0; i < input.length; i++) {
		if ((input.charCodeAt(i) == 13) && (input.charCodeAt(i + 1) == 10)) {
			i++;
			output += "<BR>";
		}
		else {
			output += input.charAt(i);
		}
	}
	return output;
}

function replaceChars(strFind,strReplace,strHTML) {
	temp = '' + strHTML; // temporary holder

	while (temp.indexOf(strFind)>-1) {
		pos= temp.indexOf(strFind);
		temp = '' + (temp.substring(0, pos) + strReplace + temp.substring((pos + strFind.length), temp.length));
	}
	return temp;
}


function Preview(form)
	{
	for (var i=0;i<document.frmMail.regions.length;i++) {
		if (document.frmMail.regions[i].checked) {
			document.frmMail.region.value = document.frmMail.regions[i].value
		}

	}

	for (var i=0;i<document.frmMail.icontype.length;i++) {
		if (document.frmMail.icontype[i].checked) {
			document.frmMail.emailIcon.value = document.frmMail.icontype[i].value
		}

	}

	for (var i=0;i<document.frmMail.services.length;i++) {
		if (document.frmMail.services[i].checked) {
			if (i == 0) {
				document.frmMail.service.value = document.frmMail.services[i].value;
			}
			else {
				document.frmMail.service.value = document.frmMail.service.value + ',' + document.frmMail.services[i].value;
			}
		}

	}
	var from = form.fromemail.value;
	var to = form.to.value;
	var bcc = form.bcc.value;
	var subject = form.subject.value;
	var service = '<b>Please be advised of an interruption to the following Stratos service(s):</b>' + form.service.value;
	var regions = '<br><br><b>Region(s) Affected:</b>' + form.region.value;
	var type = '<br><br><b>Email Type:</b> <img src=\"images/icon_' + form.emailIcon.value + '.gif\" width=\"16\" height=\"16\" border=\"0\" alt=\"' + form.emailIcon.value + '\">';
	var startdate = '<br><br><b>Service Affected:<br>Start Date:</b> ' + form.startdate.value;
	var starttime = '<br><br><b>Interruption Window Start Time:</b> ' + form.starttime.value;
	var endtime = '<br><br><b>Interruption Window End Time:</b> ' + form.endtime.value;
	var appduration = '<br><br><b>Approximate Duration:</b> ' + form.appduration.value;
	var mailtext1 = '<br><b>Reason:</b> ' + form.mailtext1.value;
	var mailtext2 = form.mailtext2.value;
	//pop = window.open('','popup', 'scrollbars = yes, toolbar = no, status = no');
	setup1 = 'toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=no,copyhistory=no,width=600,height=550';
	var pop = window.open ('','Preview',setup1);
	pop.document.open();
	pop.document.writeln('<head>');
	pop.document.writeln('<Title>');
	pop.document.writeln('Preview');
	pop.document.writeln('</Title>');
	pop.document.writeln('<link rel=\"STYLESHEET\" type=\"text/css\" href=\"styles.css\">');
	pop.document.writeln('<link rel=\"STYLESHEET\" type=\"text/css\" href=\"tree.css\">');
	pop.document.writeln('</head>');
	pop.document.writeln('<body>');
	pop.document.writeln('<div id=\"p7swapmenu\">');
	pop.document.writeln('<center>');
	pop.document.writeln('<h2>Preview</h2><br>');
	pop.document.writeln('</center>');
	pop.document.writeln('<form method=post action=\"\" name=\"frmMail\" id=\"frmMail\">');
	pop.document.writeln('<table>');
	pop.document.writeln('<tr>');
	pop.document.writeln('<td colspan=\"2\"><b>From:&nbsp;&nbsp;</b></td> <td colspan=\"2\">' + document.frmMail.fromemail.value + '</td>');
	//pop.document.writeln('<br>');
	pop.document.writeln('</tr>');
	pop.document.writeln('<tr>');
	pop.document.writeln('<td colspan=\"2\"><b>To:&nbsp;&nbsp;</b></td> <td colspan=\"2\"> ' + to + '</td>');
	//pop.document.writeln('<br>');
	pop.document.writeln('</tr>');
	pop.document.writeln('<tr>');
	pop.document.writeln('<td colspan=\"2\"><b>BCC:&nbsp;&nbsp;</b></td> <td colspan=\"2\"> ' + bcc + '</td>');
	//pop.document.writeln('<br>');
	pop.document.writeln('</tr>');
	pop.document.writeln('<tr>');
	pop.document.writeln('<td colspan=\"2\"><b>Subject:&nbsp;&nbsp;</b></td> <td colspan=\"2\"> ' + subject + '</td>');
	//pop.document.writeln('<br>');
	pop.document.writeln('</tr>');
	pop.document.writeln('<tr>');
	pop.document.writeln('<td colspan=\"2\"><b>Message:&nbsp;&nbsp;</b></td> <td colspan=\"2\"> ' + service + regions + type + startdate + starttime + endtime + appduration + '<br>' + mailtext1 + '<br><br>' + mailtext2 + '</td>');
	//pop.document.writeln('<br>');
	pop.document.writeln('</tr>');
	pop.document.writeln('</table>');
	pop.document.writeln('</form>');
	pop.document.writeln('<br><p><center><a href="javascript:window.close();">Close Window</a></p>');
	pop.document.writeln('</div>');
	pop.document.writeln('</body>');
	pop.document.close();
}


function PreviewMail()
	{
	//var from = document.frmMail.from.value
	//var to = document.frmMail.to.value
	//var mailtext = document.frmMail.mailtext.value
	alert(document.frmMail.fromemail.value);
	setup2 = 'toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=no,copyhistory=no,width=600,height=550';
	pop = window.open ("previewMail.php","pop",setup2);

}

function AddUser()
	{
	//var from = document.frmMail.from.value
	//var to = document.frmMail.to.value
	//var mailtext = document.frmMail.mailtext.value
	setup2 = 'toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=no,copyhistory=no,width=670,height=550';
	pop = window.open ("addUser.php","pop",setup2);

}

	function ProcessForm(){
		var testresults;
		var strSubmitMessage = '';
		var blnStopSubmission = false;

		//Validate Launch Date
		if (isEmpty(document.frmMail.fromemail.value)) {
			blnStopSubmission = true;
			strSubmitMessage = strSubmitMessage + '\      Please Enter From Email\n';
		}

		//Validate Launch Date
		if (isEmpty(document.frmMail.to.value)) {
			blnStopSubmission = true;
			strSubmitMessage = strSubmitMessage + '\      Please Enter To Email\n';
		}

		//Validate Launch Date
		if (isEmpty(document.frmMail.subject.value)) {
			blnStopSubmission = true;
			strSubmitMessage = strSubmitMessage + '\      Please Select a Subject\n';
		}


		for (var i=0;i<document.frmMail.services.length;i++) {
			if (document.frmMail.services[i].checked) {
				if (i == 0) {
					document.frmMail.service.value = document.frmMail.services[i].value;
				}
				else {
					document.frmMail.service.value = document.frmMail.service.value + ',' + document.frmMail.services[i].value;
				}
			}

		}

		if (isEmpty(document.frmMail.service.value)) {
			blnStopSubmission = true;
			strSubmitMessage = strSubmitMessage + '\      Please Select a Service\n';
		}
		//alert(document.frmMail.service.value);

		for (var i=0;i<document.frmMail.regions.length;i++) {
			if (document.frmMail.regions[i].checked) {
				document.frmMail.region.value = document.frmMail.regions[i].value
			}

		}

		if (isEmpty(document.frmMail.region.value)) {
			blnStopSubmission = true;
			strSubmitMessage = strSubmitMessage + '\      Please Select a Region\n';
		}
		//alert(document.frmMail.icontype.value);

		for (var i=0;i<document.frmMail.icontype.length;i++) {
			if (document.frmMail.icontype[i].checked) {
				document.frmMail.emailIcon.value = document.frmMail.icontype[i].value
			}

		}

		if (isEmpty(document.frmMail.emailIcon.value)) {
			blnStopSubmission = true;
			strSubmitMessage = strSubmitMessage + '\      Please Select a Email Type\n';
				}
		//alert(document.frmMail.emailIcon.value);

		//Submit the form
		if(!blnStopSubmission) {
			document.frmMail.submit();
		}
		else {
			alert(strSubmitMessage);
		}
	}

	//Check whether string s is empty.
	function isEmpty(s) {
		return ((s == null) || (s.length == 0))
	}

//-->
</script>

<script language="JavaScript" src="/jspellhtml/jspellpopup.js"></script>
<script language="javascript" type="text/javascript" src="datetimepicker.js"></script>
<script language="JavaScript">
<!--
var spellCheckURL="/jspellhtml/JSpell"; // change to point to the JSpell Spell Check Server
var imagePath="/jspellhtml/images"; // relative URL to JSpell button images directory

function getSpellCheckItem(jspell_n) {
   var fieldsToCheck=getSpellCheckArray();
   return fieldsToCheck[jspell_n];
}
//-->
</script>
</head>

<?php
include ("dbconfig.php");
$link = mysql_connect($host,$usr,$pwd)
or die("Could not connect : " . mysql_error());

//echo "Connected successfully";
mysql_select_db($db) or die("Could not select database");

$nowDate = date("Ymd G:i:s");
$disID = 1;

if (!$_GET['nameID'] == '') {
$nameID = $_GET['nameID'];
}

if (!$_POST['nameID'] == '') {
$nameID = $_POST['nameID'];
}

if (!$_POST['mailtext2'] == '') {
	$Disclaimer = $_POST['mailtext2'];

	$query = "UPDATE disclaimer SET disclaimer = '$Disclaimer' ,admin = '$nameID', moddate = '$nowDate' WHERE id = '$disID'";

	mysql_query($query);
}


/* Performing SQL query */
$query = "SELECT disclaimer, moddate, admin FROM disclaimer";
$result = mysql_query($query) or die("Query failed : " . mysql_error());
$adminnames ='';
/* Printing results in HTML */
while ($myrow = mysql_fetch_row($result)) {
	$disclaimer = $myrow[0];
	$moddate = $myrow[1];
	$adminID = $myrow[2];

}


if (!$adminID == '') {

	/* Performing SQL query */
	$query = "SELECT adminname,email,admintype FROM admin WHERE id ='$adminID'";
	$result = mysql_query($query) or die("Query failed : " . mysql_error());


	while ($myrow = mysql_fetch_row($result)) {
		$adminname = $myrow[0];
		$email = $myrow[1];
		$admintype = $myrow[2];
	}

	/* Free resultset */
	//mysql_free_result($result);

}

/* Free resultset */
mysql_free_result($result);

/* Closing connection */
mysql_close($link);

?>
<body>
<div id="p7swapmenu">
<form method=post action="editDisclaimer.php" name="frmMail" id="frmMail">
<input type="hidden" name="nameID" value="<?PHP echo $HTTP_COOKIE_VARS["cookid"] ?>">
 <table>
   <tr>
     <td colspan="2">Disclaimer:  </td>
     <td colspan="2"> <br><textarea name="mailtext2" cols="55" rows="5" OnSelect="StoreCaret(this);" OnClick="StoreCaret(this);" OnKeyUp="StoreCaret(this);" OnDBLClick="StoreCaret(this);"><?PHP echo $disclaimer ?></textarea>
	 <br><A HREF="#" onMouseOver="changeImages('imgBold', 'imgBoldon');window.status='Bold';return true;" onMouseOut="window.status='';changeImages('imgBold', 'imgBoldoff')" OnClick="InsertAtCursor(document.frmMail.mailtext2,'<b>','</b>','Bold');return false;"><img src="images/bold_off.gif" NAME="imgBold" WIDTH=25 HEIGHT=25 BORDER="0" ALT="Bold"><A HREF="#" onMouseOver="changeImages('imgItalic', 'imgItalicon');window.status='Italic';return true;" onMouseOut="window.status='';changeImages('imgItalic', 'imgItalicoff')" OnClick="InsertAtCursor(document.frmMail.mailtext2,'<i>','</i>','Italic');return false;"><img src="images/italic_off.gif" NAME="imgItalic" WIDTH=25 HEIGHT=25 BORDER="0" ALT="Italic"><A HREF="#" onMouseOver="changeImages('imgUnderline', 'imgUnderlineon');window.status='Underline';return true;" onMouseOut="window.status='';changeImages('imgUnderline', 'imgUnderlineoff')" OnClick="InsertAtCursor(document.frmMail.mailtext2,'<u>','</u>','Underline');return false;"><img src="images/underline_off.gif" NAME="imgUnderline" WIDTH=27 HEIGHT=25 BORDER="0" ALT="Underline"><A HREF="#" onMouseOver="changeImages('imgOrderedList', 'imgOrderedListon');window.status='Ordered List';return true;" onMouseOut="window.status='';changeImages('imgOrderedList', 'imgOrderedListoff')" OnClick="InsertLists(document.frmMail.mailtext2,'<ol>','</ol>','<li>','Ordered List');return false;"><img src="images/orderedlist_off.gif" NAME="imgOrderedList" WIDTH=27 HEIGHT=25 BORDER="0" ALT="Ordered List"><A HREF="#" onMouseOver="changeImages('imgUnorderedList', 'imgUnorderedListon');window.status='Unordered List';return true;" onMouseOut="window.status='';changeImages('imgUnorderedList', 'imgUnorderedListoff')" OnClick="InsertLists(document.frmMail.mailtext2,'<ul>','</ul>','<li>','Unordered List');return false;"><img src="images/unorderedlist_off.gif" NAME="imgUnorderedList" WIDTH=25 HEIGHT=25 BORDER="0" ALT="Unordered List"><A HREF="#" onMouseOver="changeImages('imgAlignLeft', 'imgAlignLefton');window.status='Align Left';return true;" onMouseOut="window.status='';changeImages('imgAlignLeft', 'imgAlignLeftoff')" OnClick="InsertAtCursor(document.frmMail.mailtext2,'<div align=left>','</div>','Align Left');return false;"><img src="images/alignleft_off.gif" NAME="imgAlignLeft" WIDTH=27 HEIGHT=25 BORDER="0" ALT="Align Left"><A HREF="#" onMouseOver="changeImages('imgAlignCenter', 'imgAlignCenteron');window.status='Align Center';return true;" onMouseOut="window.status='';changeImages('imgAlignCenter', 'imgAlignCenteroff')" OnClick="InsertAtCursor(document.frmMail.mailtext2,'<center>','</center>','Align Center');return false;"><img src="images/aligncenter_off.gif" NAME="imgAlignCenter" WIDTH=25 HEIGHT=25 BORDER="0" ALT="Align Center"><A HREF="#" onMouseOver="changeImages('imgAlignRight', 'imgAlignRighton');window.status='Align Right';return true;" onMouseOut="window.status='';changeImages('imgAlignRight', 'imgAlignRightoff')" OnClick="InsertAtCursor(document.frmMail.mailtext2,'<div align=right>','</div>','Align Right');return false;" ><img src="images/alignright_off.gif" NAME="imgAlignRight" WIDTH=25 HEIGHT=25 BORDER="0" ALT="Align Right"></a></td>
     Last modified by <?PHP echo $adminname ?> on <?PHP echo $moddate ?>.
     </td>
   </tr>
   <tr>
        <td colspan="4"><center><input type="Submit" name="Submit" value="Change" tabindex="8" />&nbsp;&nbsp;<input type="reset" value="Reset"></center></td>
   </tr>
</table>
<p><p>


</form>
</div>
</body>
</html>
