<html>

<link rel="STYLESHEET" type="text/css" href="styles.css">
<link rel="STYLESHEET" type="text/css" href="tree.css">

<script language="Javascript">
<!--
if (document.images) {
//on buttons
	imgBoldon = new Image();
	imgBoldon.src = "/stratos/images/bold_on.gif";
	imgItalicon = new Image();
	imgItalicon.src = "/stratos/images/italic_on.gif";
	imgUnderlineon = new Image();
	imgUnderlineon.src = "/stratos/images/underline_on.gif";
	imgOrderedListon = new Image();
	imgOrderedListon.src = "/stratos/images/orderedlist_on.gif";
	imgUnorderedListon = new Image();
	imgUnorderedListon.src = "/stratos/images/unorderedlist_on.gif";
	imgAlignLefton = new Image();
	imgAlignLefton.src = "/stratos/images/alignleft_on.gif";
	imgAlignCenteron = new Image();
	imgAlignCenteron.src = "/stratos/images/aligncenter_on.gif";
	imgAlignRighton = new Image();
	imgAlignRighton.src = "/stratos/images/alignright_on.gif";
	imgInsertLinkon = new Image();
	imgInsertLinkon.src = "/stratos/images/insertlink_on.gif";
	imgClearHtmlon = new Image();
	imgClearHtmlon.src = "/stratos/images/clearhtml_on.gif";

//off buttons
	imgBoldoff = new Image();
	imgBoldoff.src = "/stratos/images/bold_off.gif";
	imgItalicoff = new Image();
	imgItalicoff.src = "/stratos/images/italic_off.gif";
	imgUnderlineoff = new Image();
	imgUnderlineoff.src = "/stratos/images/underline_off.gif";
	imgOrderedListoff = new Image();
	imgOrderedListoff.src = "/stratos/images/orderedlist_off.gif";
	imgUnorderedListoff = new Image();
	imgUnorderedListoff.src = "/stratos/images/unorderedlist_off.gif";
	imgAlignLeftoff = new Image();
	imgAlignLeftoff.src = "/stratos/images/alignleft_off.gif";
	imgAlignCenteroff = new Image();
	imgAlignCenteroff.src = "/stratos/images/aligncenter_off.gif";
	imgAlignRightoff = new Image();
	imgAlignRightoff.src = "/stratos/images/alignright_off.gif";
	imgInsertLinkoff = new Image();
	imgInsertLinkoff.src = "/stratos/images/insertlink_off.gif";
	imgClearHtmloff = new Image();
	imgClearHtmloff.src = "/stratos/images/clearhtml_off.gif";
}

function changeImages() {
	if (document.images) {
		for (var i=0; i<changeImages.arguments.length; i+=2) {
			document[changeImages.arguments[i]].src = eval(changeImages.arguments[i+1] + ".src");
		}
	}
}

function StoreCaret (textEl) {
	var optionObject;
	optionObject = eval(textEl);

	if (optionObject.createTextRange) {
		optionObject.caretPos = document.selection.createRange().duplicate();
	}
}

function InsertAddLink (textEl,strType) {
	var url = prompt('Enter the URL location :','http:\/\/')
	var optionObject;
	optionObject = eval(textEl);
	if (url != null) {
		var strResultText = "";
		strResultText = (document.all) ? document.selection.createRange().text :
		document.frmContentTemplateStoryEditor.text.value = strResultText ;
		document.selection.createRange().text = "";
		var caretPos = optionObject.caretPos;
		caretPos.text = caretPos.text.charAt(caretPos.text.length) == ' ' ? strOpen + ' ':
		'<a href=\"' + url + '\">' + strResultText + '</a>';
	}
	window.status=strType;
}

function InsertAtCursor (textEl,strOpen,strClose,strType) {
	var strResultText = "";
	var optionObject;
	optionObject = eval(textEl);
	strResultText = (document.all) ? document.selection.createRange().text :
	document.frmContentTemplateStoryEditor.text.value = strResultText ;
	document.selection.createRange().text = "";
	if (optionObject.createTextRange && optionObject.caretPos) {
		var caretPos = optionObject.caretPos;
		caretPos.text = caretPos.text.charAt(caretPos.text.length) == ' ' ? strOpen + ' ':
		strOpen + strResultText + strClose;
	}
	window.status=strType;
}

function InsertLists(textEl,strOpen,strClose,strDivider,strType) {
	var strResultText = "";
	var optionObject;
	optionObject = eval(textEl);
	strResultText = (document.all) ? document.selection.createRange().text :
	document.frmContentTemplateStoryEditor.text.value = strResultText ;
	var strOutPut = "";
	document.selection.createRange().text = "";
	if (optionObject.createTextRange && optionObject.caretPos) {
		for (var i = 0; i < strResultText.length; i++) {
			if ((strResultText.charCodeAt(i) == 13) && (strResultText.charCodeAt(i + 1) == 10)) {
				i++;
				strOutPut += "\r\n" + strDivider;
			}
			else {
				strOutPut += strResultText.charAt(i);
			}
		}
		var caretPos = optionObject.caretPos;
		caretPos.text = caretPos.text.charAt(caretPos.text.length) == ' ' ? strOpen + ' ':
		strOpen + strDivider + strOutPut + strClose + "\r\n";
	}
	window.status=strType;
}

function ClearTags(textEl,strType) {
	var optionObject;
	optionObject = eval(textEl);
	if (!confirm("Are you sure you want to delete the HTML in the " + strType + "?")) {
		optionObject = optionObject.value.replace(/<[^>]*>/g,'');
	//	document.frmContentTemplateStoryEditor.strContentTemplateHeader.value = textEl.replace(/<[^>]*>/g,'');
	}
}

function ConvertBR(input) {
// Converts carriage returns
// to <BR> for display in HTML
	var output = "";
	for (var i = 0; i < input.length; i++) {
		if ((input.charCodeAt(i) == 13) && (input.charCodeAt(i + 1) == 10)) {
			i++;
			output += "<BR>";
		}
		else {
			output += input.charAt(i);
		}
	}
	return output;
}

function replaceChars(strFind,strReplace,strHTML) {
	temp = '' + strHTML; // temporary holder

	while (temp.indexOf(strFind)>-1) {
		pos= temp.indexOf(strFind);
		temp = '' + (temp.substring(0, pos) + strReplace + temp.substring((pos + strFind.length), temp.length));
	}
	return temp;
}

	function Preview()
		{
		var from = document.frmMail.from.value
		var to = document.frmMail.to.value
		var mailtext = document.frmMail.mailtext.value
		setup = 'toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=no,resizable=no,copyhistory=no,width=600,height=550';
		pop = window.open ("","pop",setup);
		pop.location.reload();
		pop.document.write('<head>');
		pop.document.write('<Title>');
		pop.document.write('Preview');
		pop.document.write('</Title>');
		pop.document.write('<link rel=\"STYLESHEET\" type=\"text/css\" href=\"styles.css\">');
		pop.document.write('</head>');
		pop.document.write('<body>');
		pop.document.write('<center>');
		pop.document.write('<h2>Preview</h2><br>');
		pop.document.write('</center>');
		pop.document.write('From: ' + from)
		pop.document.write('<br>')
		pop.document.write('To: ' + to)
		pop.document.write('<br>')
		pop.document.write('Message: ' + mailtext)
		pop.document.write('<br>')
		pop.document.write('<br><p><center><a href="javascript:window.close();">Close Window</a></p>');
		pop.document.write('</body>');

		}

	function checkAll(field)
	{
		for (var i = 0; i < field.length; i++ ){
			field[i].checked = true ;
		}
	}

	function decheckAll(field)
		{
			for (var i = 0; i < field.length; i++ ){
				field[i].checked = false ;
			}
	}

	var strUsers = '';
	// Get selected value from selection list.
	function getSelectionValue (option1, option2) {
		for (var i = 0; i < option1.length; i++) {
			if (option1[i].checked) {
				if (strUsers == '') {
					strUsers = option1[i].value;
				}
				else {
					strUsers = strUsers + '; ' + option1[i].value;
				}
			}
		}

		for (var i = 0; i < option2.length; i++) {
			if (option2[i].checked) {
				if (strUsers == '') {
					strUsers = option2[i].value;
				}
				else {
					strUsers = strUsers + '; ' + option2[i].value;
				}
			}
		}

		opener.document.frmMail.to.value = strUsers;
		window.close();
	}


//-->
</script>

<script language="JavaScript" src="/jspellhtml/jspellpopup.js"></script>
<script language="JavaScript">
<!--
var spellCheckURL="/jspellhtml/JSpell"; // change to point to the JSpell Spell Check Server
var imagePath="/jspellhtml/images"; // relative URL to JSpell button images directory

function getSpellCheckItem(jspell_n) {
   var fieldsToCheck=getSpellCheckArray();
   return fieldsToCheck[jspell_n];
}
//-->
</script>

<body>

<form method=post action="" name="frmMail" id="frmMail">
<div id="p7swapmenu">
<table>
   <tr align=\"top\">
<?php
include ("dbconfig.php");
$link = mysql_connect($host,$usr,$pwd)
or die("Could not connect : " . mysql_error());

//echo "Connected successfully";
mysql_select_db($db) or die("Could not select database");

/* Performing SQL query */
$query = "SELECT DISTINCT companyname FROM users ORDER BY companyname";
$result = mysql_query($query) or die("Query failed : " . mysql_error());

$query1 = "SELECT DISTINCT groupname FROM groups ORDER BY groupname";
$result1 = mysql_query($query1) or die("Query failed : " . mysql_error());

$query2 = "SELECT DISTINCT username,email FROM users ORDER BY username";
$result2 = mysql_query($query2) or die("Query failed : " . mysql_error());

/* Printing results in HTML */
printf("<td colspan=\"2\"><label for=\"name\"><b>Company List</b></label></td>");
printf("<td colspan=\"2\"><label for=\"name\"><b>User List</b></label></td></tr>");
printf("<tr><td colspan=\"2\" align=\"top\">");
while ($myrow = mysql_fetch_row($result)) {

	printf("\t\t<input type=\"checkbox\" name=\"compselect\" value=\"%s\">  ".$myrow[0]."<br>", $myrow[0]);

}

printf("<p><center><input type=\"button\" name=\"Select All\" value=\"Select All\" OnClick=\"checkAll(document.frmMail.compselect);\"/>&nbsp;&nbsp;<input type=\"button\" value=\"Deselect All\" onClick=\"decheckAll(document.frmMail.compselect);\"></center></p></td>");

printf("<td colspan=\"2\" align=\"top\">");
while ($myrow = mysql_fetch_row($result2)) {

	printf("\t\t<input type=\"checkbox\" name=\"userselect\" value=\"%s\">  ".$myrow[0]."<br>", $myrow[1]);

}

printf("<p><center><input type=\"button\" name=\"Select All\" value=\"Select All\" OnClick=\"checkAll(document.frmMail.userselect);\"/>&nbsp;&nbsp;<input type=\"button\" value=\"Deselect All\" onClick=\"decheckAll(document.frmMail.userselect);\"></center></p></td>");
/* Free resultset */
mysql_free_result($result);
mysql_free_result($result2);

/* Closing connection */
mysql_close($link);
?>

   </tr>
</table>
<p><center><input type="button" name="Done" value="Done" OnClick="getSelectionValue(document.frmMail.compselect, document.frmMail.userselect);"/>&nbsp;&nbsp;<input type="button" value="Reset"></center></p>
</form>
</div>
</body>
</html>